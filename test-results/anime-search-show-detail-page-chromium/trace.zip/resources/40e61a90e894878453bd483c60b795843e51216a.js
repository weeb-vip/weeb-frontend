function r(e){return new Worker("/assets/animeNotifications.worker-BTkQaIBp.js",{type:"module",name:e?.name})}export{r as default};
