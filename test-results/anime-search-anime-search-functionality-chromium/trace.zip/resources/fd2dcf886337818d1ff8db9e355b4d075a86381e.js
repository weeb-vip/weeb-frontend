import{g as Ia}from"./react-vendor-DOsPXCUf.js";import{R as S,r as c,e as on}from"./router-CHX7Q9Y1.js";import{r as Ca}from"./query-UgOCjoEt.js";function Jn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(a){return Object.getOwnPropertyDescriptor(e,a).enumerable})),n.push.apply(n,r)}return n}function y(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]!=null?arguments[t]:{};t%2?Jn(Object(n),!0).forEach(function(r){B(e,r,n[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Jn(Object(n)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(n,r))})}return e}function kt(e){"@babel/helpers - typeof";return kt=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},kt(e)}function $a(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function Ra(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function Na(e,t,n){return t&&Ra(e.prototype,t),Object.defineProperty(e,"prototype",{writable:!1}),e}function B(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function An(e,t){return La(e)||Da(e,t)||Nr(e,t)||ja()}function Ze(e){return Fa(e)||Ma(e)||Nr(e)||_a()}function Fa(e){if(Array.isArray(e))return sn(e)}function La(e){if(Array.isArray(e))return e}function Ma(e){if(typeof Symbol<"u"&&e[Symbol.iterator]!=null||e["@@iterator"]!=null)return Array.from(e)}function Da(e,t){var n=e==null?null:typeof Symbol<"u"&&e[Symbol.iterator]||e["@@iterator"];if(n!=null){var r=[],a=!0,o=!1,i,s;try{for(n=n.call(e);!(a=(i=n.next()).done)&&(r.push(i.value),!(t&&r.length===t));a=!0);}catch(l){o=!0,s=l}finally{try{!a&&n.return!=null&&n.return()}finally{if(o)throw s}}return r}}function Nr(e,t){if(e){if(typeof e=="string")return sn(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if(n==="Object"&&e.constructor&&(n=e.constructor.name),n==="Map"||n==="Set")return Array.from(e);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return sn(e,t)}}function sn(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}function _a(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function ja(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var Zn=function(){},On={},Fr={},Lr=null,Mr={mark:Zn,measure:Zn};try{typeof window<"u"&&(On=window),typeof document<"u"&&(Fr=document),typeof MutationObserver<"u"&&(Lr=MutationObserver),typeof performance<"u"&&(Mr=performance)}catch{}var za=On.navigator||{},er=za.userAgent,tr=er===void 0?"":er,xe=On,M=Fr,nr=Lr,ft=Mr;xe.document;var be=!!M.documentElement&&!!M.head&&typeof M.addEventListener=="function"&&typeof M.createElement=="function",Dr=~tr.indexOf("MSIE")||~tr.indexOf("Trident/"),ct,dt,mt,pt,vt,pe="___FONT_AWESOME___",ln=16,_r="fa",jr="svg-inline--fa",Ie="data-fa-i2svg",un="data-fa-pseudo-element",Ha="data-fa-pseudo-element-pending",Tn="data-prefix",In="data-icon",rr="fontawesome-i2svg",Ua="async",Ya=["HTML","HEAD","STYLE","SCRIPT"],zr=function(){try{return!0}catch{return!1}}(),L="classic",z="sharp",Cn=[L,z];function et(e){return new Proxy(e,{get:function(n,r){return r in n?n[r]:n[L]}})}var qe=et((ct={},B(ct,L,{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fad:"duotone","fa-duotone":"duotone",fab:"brands","fa-brands":"brands",fak:"kit","fa-kit":"kit"}),B(ct,z,{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light"}),ct)),Ve=et((dt={},B(dt,L,{solid:"fas",regular:"far",light:"fal",thin:"fat",duotone:"fad",brands:"fab",kit:"fak"}),B(dt,z,{solid:"fass",regular:"fasr",light:"fasl"}),dt)),Xe=et((mt={},B(mt,L,{fab:"fa-brands",fad:"fa-duotone",fak:"fa-kit",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"}),B(mt,z,{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light"}),mt)),Wa=et((pt={},B(pt,L,{"fa-brands":"fab","fa-duotone":"fad","fa-kit":"fak","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"}),B(pt,z,{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl"}),pt)),Ba=/fa(s|r|l|t|d|b|k|ss|sr|sl)?[\-\ ]/,Hr="fa-layers-text",Ga=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp|Kit)?.*/i,qa=et((vt={},B(vt,L,{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"}),B(vt,z,{900:"fass",400:"fasr",300:"fasl"}),vt)),Ur=[1,2,3,4,5,6,7,8,9,10],Va=Ur.concat([11,12,13,14,15,16,17,18,19,20]),Xa=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],Ae={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},Ke=new Set;Object.keys(Ve[L]).map(Ke.add.bind(Ke));Object.keys(Ve[z]).map(Ke.add.bind(Ke));var Ka=[].concat(Cn,Ze(Ke),["2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","fw","inverse","layers-counter","layers-text","layers","li","pull-left","pull-right","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul",Ae.GROUP,Ae.SWAP_OPACITY,Ae.PRIMARY,Ae.SECONDARY]).concat(Ur.map(function(e){return"".concat(e,"x")})).concat(Va.map(function(e){return"w-".concat(e)})),Be=xe.FontAwesomeConfig||{};function Qa(e){var t=M.querySelector("script["+e+"]");if(t)return t.getAttribute(e)}function Ja(e){return e===""?!0:e==="false"?!1:e==="true"?!0:e}if(M&&typeof M.querySelector=="function"){var Za=[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-auto-a11y","autoA11y"],["data-search-pseudo-elements","searchPseudoElements"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]];Za.forEach(function(e){var t=An(e,2),n=t[0],r=t[1],a=Ja(Qa(n));a!=null&&(Be[r]=a)})}var Yr={styleDefault:"solid",familyDefault:"classic",cssPrefix:_r,replacementClass:jr,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};Be.familyPrefix&&(Be.cssPrefix=Be.familyPrefix);var De=y(y({},Yr),Be);De.autoReplaceSvg||(De.observeMutations=!1);var w={};Object.keys(Yr).forEach(function(e){Object.defineProperty(w,e,{enumerable:!0,set:function(n){De[e]=n,Ge.forEach(function(r){return r(w)})},get:function(){return De[e]}})});Object.defineProperty(w,"familyPrefix",{enumerable:!0,set:function(t){De.cssPrefix=t,Ge.forEach(function(n){return n(w)})},get:function(){return De.cssPrefix}});xe.FontAwesomeConfig=w;var Ge=[];function ei(e){return Ge.push(e),function(){Ge.splice(Ge.indexOf(e),1)}}var Re=ln,ue={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function ti(e){if(!(!e||!be)){var t=M.createElement("style");t.setAttribute("type","text/css"),t.innerHTML=e;for(var n=M.head.childNodes,r=null,a=n.length-1;a>-1;a--){var o=n[a],i=(o.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(i)>-1&&(r=o)}return M.head.insertBefore(t,r),e}}var ni="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function Qe(){for(var e=12,t="";e-- >0;)t+=ni[Math.random()*62|0];return t}function je(e){for(var t=[],n=(e||[]).length>>>0;n--;)t[n]=e[n];return t}function $n(e){return e.classList?je(e.classList):(e.getAttribute("class")||"").split(" ").filter(function(t){return t})}function Wr(e){return"".concat(e).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function ri(e){return Object.keys(e||{}).reduce(function(t,n){return t+"".concat(n,'="').concat(Wr(e[n]),'" ')},"").trim()}function Ot(e){return Object.keys(e||{}).reduce(function(t,n){return t+"".concat(n,": ").concat(e[n].trim(),";")},"")}function Rn(e){return e.size!==ue.size||e.x!==ue.x||e.y!==ue.y||e.rotate!==ue.rotate||e.flipX||e.flipY}function ai(e){var t=e.transform,n=e.containerWidth,r=e.iconWidth,a={transform:"translate(".concat(n/2," 256)")},o="translate(".concat(t.x*32,", ").concat(t.y*32,") "),i="scale(".concat(t.size/16*(t.flipX?-1:1),", ").concat(t.size/16*(t.flipY?-1:1),") "),s="rotate(".concat(t.rotate," 0 0)"),l={transform:"".concat(o," ").concat(i," ").concat(s)},f={transform:"translate(".concat(r/2*-1," -256)")};return{outer:a,inner:l,path:f}}function ii(e){var t=e.transform,n=e.width,r=n===void 0?ln:n,a=e.height,o=a===void 0?ln:a,i="";return Dr?i+="translate(".concat(t.x/Re-r/2,"em, ").concat(t.y/Re-o/2,"em) "):i+="translate(calc(-50% + ".concat(t.x/Re,"em), calc(-50% + ").concat(t.y/Re,"em)) "),i+="scale(".concat(t.size/Re*(t.flipX?-1:1),", ").concat(t.size/Re*(t.flipY?-1:1),") "),i+="rotate(".concat(t.rotate,"deg) "),i}var oi=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-counter-scale, 0.25));
          transform: scale(var(--fa-counter-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom right;
          transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom left;
          transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top left;
          transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(var(--fa-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  -webkit-animation-name: fa-beat;
          animation-name: fa-beat;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  -webkit-animation-name: fa-bounce;
          animation-name: fa-bounce;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  -webkit-animation-name: fa-fade;
          animation-name: fa-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  -webkit-animation-name: fa-beat-fade;
          animation-name: fa-beat-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  -webkit-animation-name: fa-flip;
          animation-name: fa-flip;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  -webkit-animation-name: fa-shake;
          animation-name: fa-shake;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 2s);
          animation-duration: var(--fa-animation-duration, 2s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));
          animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    -webkit-animation-delay: -1ms;
            animation-delay: -1ms;
    -webkit-animation-duration: 1ms;
            animation-duration: 1ms;
    -webkit-animation-iteration-count: 1;
            animation-iteration-count: 1;
    -webkit-transition-delay: 0s;
            transition-delay: 0s;
    -webkit-transition-duration: 0s;
            transition-duration: 0s;
  }
}
@-webkit-keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@-webkit-keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@-webkit-keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@-webkit-keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@-webkit-keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@-webkit-keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@-webkit-keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
@keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}

.fa-rotate-180 {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}

.fa-rotate-270 {
  -webkit-transform: rotate(270deg);
          transform: rotate(270deg);
}

.fa-flip-horizontal {
  -webkit-transform: scale(-1, 1);
          transform: scale(-1, 1);
}

.fa-flip-vertical {
  -webkit-transform: scale(1, -1);
          transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  -webkit-transform: scale(-1, -1);
          transform: scale(-1, -1);
}

.fa-rotate-by {
  -webkit-transform: rotate(var(--fa-rotate-angle, none));
          transform: rotate(var(--fa-rotate-angle, none));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;function Br(){var e=_r,t=jr,n=w.cssPrefix,r=w.replacementClass,a=oi;if(n!==e||r!==t){var o=new RegExp("\\.".concat(e,"\\-"),"g"),i=new RegExp("\\--".concat(e,"\\-"),"g"),s=new RegExp("\\.".concat(t),"g");a=a.replace(o,".".concat(n,"-")).replace(i,"--".concat(n,"-")).replace(s,".".concat(r))}return a}var ar=!1;function Yt(){w.autoAddCss&&!ar&&(ti(Br()),ar=!0)}var si={mixout:function(){return{dom:{css:Br,insertCss:Yt}}},hooks:function(){return{beforeDOMElementCreation:function(){Yt()},beforeI2svg:function(){Yt()}}}},ve=xe||{};ve[pe]||(ve[pe]={});ve[pe].styles||(ve[pe].styles={});ve[pe].hooks||(ve[pe].hooks={});ve[pe].shims||(ve[pe].shims=[]);var ae=ve[pe],Gr=[],li=function e(){M.removeEventListener("DOMContentLoaded",e),Et=1,Gr.map(function(t){return t()})},Et=!1;be&&(Et=(M.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(M.readyState),Et||M.addEventListener("DOMContentLoaded",li));function ui(e){be&&(Et?setTimeout(e,0):Gr.push(e))}function tt(e){var t=e.tag,n=e.attributes,r=n===void 0?{}:n,a=e.children,o=a===void 0?[]:a;return typeof e=="string"?Wr(e):"<".concat(t," ").concat(ri(r),">").concat(o.map(tt).join(""),"</").concat(t,">")}function ir(e,t,n){if(e&&e[t]&&e[t][n])return{prefix:t,iconName:n,icon:e[t][n]}}var Wt=function(t,n,r,a){var o=Object.keys(t),i=o.length,s=n,l,f,u;for(r===void 0?(l=1,u=t[o[0]]):(l=0,u=r);l<i;l++)f=o[l],u=s(u,t[f],f,t);return u};function fi(e){for(var t=[],n=0,r=e.length;n<r;){var a=e.charCodeAt(n++);if(a>=55296&&a<=56319&&n<r){var o=e.charCodeAt(n++);(o&64512)==56320?t.push(((a&1023)<<10)+(o&1023)+65536):(t.push(a),n--)}else t.push(a)}return t}function fn(e){var t=fi(e);return t.length===1?t[0].toString(16):null}function ci(e,t){var n=e.length,r=e.charCodeAt(t),a;return r>=55296&&r<=56319&&n>t+1&&(a=e.charCodeAt(t+1),a>=56320&&a<=57343)?(r-55296)*1024+a-56320+65536:r}function or(e){return Object.keys(e).reduce(function(t,n){var r=e[n],a=!!r.icon;return a?t[r.iconName]=r.icon:t[n]=r,t},{})}function cn(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},r=n.skipHooks,a=r===void 0?!1:r,o=or(t);typeof ae.hooks.addPack=="function"&&!a?ae.hooks.addPack(e,or(t)):ae.styles[e]=y(y({},ae.styles[e]||{}),o),e==="fas"&&cn("fa",t)}var gt,bt,ht,Ne=ae.styles,di=ae.shims,mi=(gt={},B(gt,L,Object.values(Xe[L])),B(gt,z,Object.values(Xe[z])),gt),Nn=null,qr={},Vr={},Xr={},Kr={},Qr={},pi=(bt={},B(bt,L,Object.keys(qe[L])),B(bt,z,Object.keys(qe[z])),bt);function vi(e){return~Ka.indexOf(e)}function gi(e,t){var n=t.split("-"),r=n[0],a=n.slice(1).join("-");return r===e&&a!==""&&!vi(a)?a:null}var Jr=function(){var t=function(o){return Wt(Ne,function(i,s,l){return i[l]=Wt(s,o,{}),i},{})};qr=t(function(a,o,i){if(o[3]&&(a[o[3]]=i),o[2]){var s=o[2].filter(function(l){return typeof l=="number"});s.forEach(function(l){a[l.toString(16)]=i})}return a}),Vr=t(function(a,o,i){if(a[i]=i,o[2]){var s=o[2].filter(function(l){return typeof l=="string"});s.forEach(function(l){a[l]=i})}return a}),Qr=t(function(a,o,i){var s=o[2];return a[i]=i,s.forEach(function(l){a[l]=i}),a});var n="far"in Ne||w.autoFetchSvg,r=Wt(di,function(a,o){var i=o[0],s=o[1],l=o[2];return s==="far"&&!n&&(s="fas"),typeof i=="string"&&(a.names[i]={prefix:s,iconName:l}),typeof i=="number"&&(a.unicodes[i.toString(16)]={prefix:s,iconName:l}),a},{names:{},unicodes:{}});Xr=r.names,Kr=r.unicodes,Nn=Tt(w.styleDefault,{family:w.familyDefault})};ei(function(e){Nn=Tt(e.styleDefault,{family:w.familyDefault})});Jr();function Fn(e,t){return(qr[e]||{})[t]}function bi(e,t){return(Vr[e]||{})[t]}function Oe(e,t){return(Qr[e]||{})[t]}function Zr(e){return Xr[e]||{prefix:null,iconName:null}}function hi(e){var t=Kr[e],n=Fn("fas",e);return t||(n?{prefix:"fas",iconName:n}:null)||{prefix:null,iconName:null}}function ke(){return Nn}var Ln=function(){return{prefix:null,iconName:null,rest:[]}};function Tt(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=t.family,r=n===void 0?L:n,a=qe[r][e],o=Ve[r][e]||Ve[r][a],i=e in ae.styles?e:null;return o||i||null}var sr=(ht={},B(ht,L,Object.keys(Xe[L])),B(ht,z,Object.keys(Xe[z])),ht);function It(e){var t,n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=n.skipLookups,a=r===void 0?!1:r,o=(t={},B(t,L,"".concat(w.cssPrefix,"-").concat(L)),B(t,z,"".concat(w.cssPrefix,"-").concat(z)),t),i=null,s=L;(e.includes(o[L])||e.some(function(f){return sr[L].includes(f)}))&&(s=L),(e.includes(o[z])||e.some(function(f){return sr[z].includes(f)}))&&(s=z);var l=e.reduce(function(f,u){var d=gi(w.cssPrefix,u);if(Ne[u]?(u=mi[s].includes(u)?Wa[s][u]:u,i=u,f.prefix=u):pi[s].indexOf(u)>-1?(i=u,f.prefix=Tt(u,{family:s})):d?f.iconName=d:u!==w.replacementClass&&u!==o[L]&&u!==o[z]&&f.rest.push(u),!a&&f.prefix&&f.iconName){var m=i==="fa"?Zr(f.iconName):{},b=Oe(f.prefix,f.iconName);m.prefix&&(i=null),f.iconName=m.iconName||b||f.iconName,f.prefix=m.prefix||f.prefix,f.prefix==="far"&&!Ne.far&&Ne.fas&&!w.autoFetchSvg&&(f.prefix="fas")}return f},Ln());return(e.includes("fa-brands")||e.includes("fab"))&&(l.prefix="fab"),(e.includes("fa-duotone")||e.includes("fad"))&&(l.prefix="fad"),!l.prefix&&s===z&&(Ne.fass||w.autoFetchSvg)&&(l.prefix="fass",l.iconName=Oe(l.prefix,l.iconName)||l.iconName),(l.prefix==="fa"||i==="fa")&&(l.prefix=ke()||"fas"),l}var yi=function(){function e(){$a(this,e),this.definitions={}}return Na(e,[{key:"add",value:function(){for(var n=this,r=arguments.length,a=new Array(r),o=0;o<r;o++)a[o]=arguments[o];var i=a.reduce(this._pullDefinitions,{});Object.keys(i).forEach(function(s){n.definitions[s]=y(y({},n.definitions[s]||{}),i[s]),cn(s,i[s]);var l=Xe[L][s];l&&cn(l,i[s]),Jr()})}},{key:"reset",value:function(){this.definitions={}}},{key:"_pullDefinitions",value:function(n,r){var a=r.prefix&&r.iconName&&r.icon?{0:r}:r;return Object.keys(a).map(function(o){var i=a[o],s=i.prefix,l=i.iconName,f=i.icon,u=f[2];n[s]||(n[s]={}),u.length>0&&u.forEach(function(d){typeof d=="string"&&(n[s][d]=f)}),n[s][l]=f}),n}}]),e}(),lr=[],Fe={},Me={},wi=Object.keys(Me);function xi(e,t){var n=t.mixoutsTo;return lr=e,Fe={},Object.keys(Me).forEach(function(r){wi.indexOf(r)===-1&&delete Me[r]}),lr.forEach(function(r){var a=r.mixout?r.mixout():{};if(Object.keys(a).forEach(function(i){typeof a[i]=="function"&&(n[i]=a[i]),kt(a[i])==="object"&&Object.keys(a[i]).forEach(function(s){n[i]||(n[i]={}),n[i][s]=a[i][s]})}),r.hooks){var o=r.hooks();Object.keys(o).forEach(function(i){Fe[i]||(Fe[i]=[]),Fe[i].push(o[i])})}r.provides&&r.provides(Me)}),n}function dn(e,t){for(var n=arguments.length,r=new Array(n>2?n-2:0),a=2;a<n;a++)r[a-2]=arguments[a];var o=Fe[e]||[];return o.forEach(function(i){t=i.apply(null,[t].concat(r))}),t}function Ce(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];var a=Fe[e]||[];a.forEach(function(o){o.apply(null,n)})}function ge(){var e=arguments[0],t=Array.prototype.slice.call(arguments,1);return Me[e]?Me[e].apply(null,t):void 0}function mn(e){e.prefix==="fa"&&(e.prefix="fas");var t=e.iconName,n=e.prefix||ke();if(t)return t=Oe(n,t)||t,ir(ea.definitions,n,t)||ir(ae.styles,n,t)}var ea=new yi,ki=function(){w.autoReplaceSvg=!1,w.observeMutations=!1,Ce("noAuto")},Ei={i2svg:function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return be?(Ce("beforeI2svg",t),ge("pseudoElements2svg",t),ge("i2svg",t)):Promise.reject("Operation requires a DOM of some kind.")},watch:function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=t.autoReplaceSvgRoot;w.autoReplaceSvg===!1&&(w.autoReplaceSvg=!0),w.observeMutations=!0,ui(function(){Pi({autoReplaceSvgRoot:n}),Ce("watch",t)})}},Si={icon:function(t){if(t===null)return null;if(kt(t)==="object"&&t.prefix&&t.iconName)return{prefix:t.prefix,iconName:Oe(t.prefix,t.iconName)||t.iconName};if(Array.isArray(t)&&t.length===2){var n=t[1].indexOf("fa-")===0?t[1].slice(3):t[1],r=Tt(t[0]);return{prefix:r,iconName:Oe(r,n)||n}}if(typeof t=="string"&&(t.indexOf("".concat(w.cssPrefix,"-"))>-1||t.match(Ba))){var a=It(t.split(" "),{skipLookups:!0});return{prefix:a.prefix||ke(),iconName:Oe(a.prefix,a.iconName)||a.iconName}}if(typeof t=="string"){var o=ke();return{prefix:o,iconName:Oe(o,t)||t}}}},ee={noAuto:ki,config:w,dom:Ei,parse:Si,library:ea,findIconDefinition:mn,toHtml:tt},Pi=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=t.autoReplaceSvgRoot,r=n===void 0?M:n;(Object.keys(ae.styles).length>0||w.autoFetchSvg)&&be&&w.autoReplaceSvg&&ee.dom.i2svg({node:r})};function Ct(e,t){return Object.defineProperty(e,"abstract",{get:t}),Object.defineProperty(e,"html",{get:function(){return e.abstract.map(function(r){return tt(r)})}}),Object.defineProperty(e,"node",{get:function(){if(be){var r=M.createElement("div");return r.innerHTML=e.html,r.children}}}),e}function Ai(e){var t=e.children,n=e.main,r=e.mask,a=e.attributes,o=e.styles,i=e.transform;if(Rn(i)&&n.found&&!r.found){var s=n.width,l=n.height,f={x:s/l/2,y:.5};a.style=Ot(y(y({},o),{},{"transform-origin":"".concat(f.x+i.x/16,"em ").concat(f.y+i.y/16,"em")}))}return[{tag:"svg",attributes:a,children:t}]}function Oi(e){var t=e.prefix,n=e.iconName,r=e.children,a=e.attributes,o=e.symbol,i=o===!0?"".concat(t,"-").concat(w.cssPrefix,"-").concat(n):o;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:y(y({},a),{},{id:i}),children:r}]}]}function Mn(e){var t=e.icons,n=t.main,r=t.mask,a=e.prefix,o=e.iconName,i=e.transform,s=e.symbol,l=e.title,f=e.maskId,u=e.titleId,d=e.extra,m=e.watchable,b=m===void 0?!1:m,p=r.found?r:n,v=p.width,h=p.height,x=a==="fak",g=[w.replacementClass,o?"".concat(w.cssPrefix,"-").concat(o):""].filter(function($){return d.classes.indexOf($)===-1}).filter(function($){return $!==""||!!$}).concat(d.classes).join(" "),O={children:[],attributes:y(y({},d.attributes),{},{"data-prefix":a,"data-icon":o,class:g,role:d.attributes.role||"img",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 ".concat(v," ").concat(h)})},k=x&&!~d.classes.indexOf("fa-fw")?{width:"".concat(v/h*16*.0625,"em")}:{};b&&(O.attributes[Ie]=""),l&&(O.children.push({tag:"title",attributes:{id:O.attributes["aria-labelledby"]||"title-".concat(u||Qe())},children:[l]}),delete O.attributes.title);var E=y(y({},O),{},{prefix:a,iconName:o,main:n,mask:r,maskId:f,transform:i,symbol:s,styles:y(y({},k),d.styles)}),j=r.found&&n.found?ge("generateAbstractMask",E)||{children:[],attributes:{}}:ge("generateAbstractIcon",E)||{children:[],attributes:{}},T=j.children,N=j.attributes;return E.children=T,E.attributes=N,s?Oi(E):Ai(E)}function ur(e){var t=e.content,n=e.width,r=e.height,a=e.transform,o=e.title,i=e.extra,s=e.watchable,l=s===void 0?!1:s,f=y(y(y({},i.attributes),o?{title:o}:{}),{},{class:i.classes.join(" ")});l&&(f[Ie]="");var u=y({},i.styles);Rn(a)&&(u.transform=ii({transform:a,width:n,height:r}),u["-webkit-transform"]=u.transform);var d=Ot(u);d.length>0&&(f.style=d);var m=[];return m.push({tag:"span",attributes:f,children:[t]}),o&&m.push({tag:"span",attributes:{class:"sr-only"},children:[o]}),m}function Ti(e){var t=e.content,n=e.title,r=e.extra,a=y(y(y({},r.attributes),n?{title:n}:{}),{},{class:r.classes.join(" ")}),o=Ot(r.styles);o.length>0&&(a.style=o);var i=[];return i.push({tag:"span",attributes:a,children:[t]}),n&&i.push({tag:"span",attributes:{class:"sr-only"},children:[n]}),i}var Bt=ae.styles;function pn(e){var t=e[0],n=e[1],r=e.slice(4),a=An(r,1),o=a[0],i=null;return Array.isArray(o)?i={tag:"g",attributes:{class:"".concat(w.cssPrefix,"-").concat(Ae.GROUP)},children:[{tag:"path",attributes:{class:"".concat(w.cssPrefix,"-").concat(Ae.SECONDARY),fill:"currentColor",d:o[0]}},{tag:"path",attributes:{class:"".concat(w.cssPrefix,"-").concat(Ae.PRIMARY),fill:"currentColor",d:o[1]}}]}:i={tag:"path",attributes:{fill:"currentColor",d:o}},{found:!0,width:t,height:n,icon:i}}var Ii={found:!1,width:512,height:512};function Ci(e,t){!zr&&!w.showMissingIcons&&e&&console.error('Icon with name "'.concat(e,'" and prefix "').concat(t,'" is missing.'))}function vn(e,t){var n=t;return t==="fa"&&w.styleDefault!==null&&(t=ke()),new Promise(function(r,a){if(ge("missingIconAbstract"),n==="fa"){var o=Zr(e)||{};e=o.iconName||e,t=o.prefix||t}if(e&&t&&Bt[t]&&Bt[t][e]){var i=Bt[t][e];return r(pn(i))}Ci(e,t),r(y(y({},Ii),{},{icon:w.showMissingIcons&&e?ge("missingIconAbstract")||{}:{}}))})}var fr=function(){},gn=w.measurePerformance&&ft&&ft.mark&&ft.measure?ft:{mark:fr,measure:fr},We='FA "6.4.0"',$i=function(t){return gn.mark("".concat(We," ").concat(t," begins")),function(){return ta(t)}},ta=function(t){gn.mark("".concat(We," ").concat(t," ends")),gn.measure("".concat(We," ").concat(t),"".concat(We," ").concat(t," begins"),"".concat(We," ").concat(t," ends"))},Dn={begin:$i,end:ta},wt=function(){};function cr(e){var t=e.getAttribute?e.getAttribute(Ie):null;return typeof t=="string"}function Ri(e){var t=e.getAttribute?e.getAttribute(Tn):null,n=e.getAttribute?e.getAttribute(In):null;return t&&n}function Ni(e){return e&&e.classList&&e.classList.contains&&e.classList.contains(w.replacementClass)}function Fi(){if(w.autoReplaceSvg===!0)return xt.replace;var e=xt[w.autoReplaceSvg];return e||xt.replace}function Li(e){return M.createElementNS("http://www.w3.org/2000/svg",e)}function Mi(e){return M.createElement(e)}function na(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=t.ceFn,r=n===void 0?e.tag==="svg"?Li:Mi:n;if(typeof e=="string")return M.createTextNode(e);var a=r(e.tag);Object.keys(e.attributes||[]).forEach(function(i){a.setAttribute(i,e.attributes[i])});var o=e.children||[];return o.forEach(function(i){a.appendChild(na(i,{ceFn:r}))}),a}function Di(e){var t=" ".concat(e.outerHTML," ");return t="".concat(t,"Font Awesome fontawesome.com "),t}var xt={replace:function(t){var n=t[0];if(n.parentNode)if(t[1].forEach(function(a){n.parentNode.insertBefore(na(a),n)}),n.getAttribute(Ie)===null&&w.keepOriginalSource){var r=M.createComment(Di(n));n.parentNode.replaceChild(r,n)}else n.remove()},nest:function(t){var n=t[0],r=t[1];if(~$n(n).indexOf(w.replacementClass))return xt.replace(t);var a=new RegExp("".concat(w.cssPrefix,"-.*"));if(delete r[0].attributes.id,r[0].attributes.class){var o=r[0].attributes.class.split(" ").reduce(function(s,l){return l===w.replacementClass||l.match(a)?s.toSvg.push(l):s.toNode.push(l),s},{toNode:[],toSvg:[]});r[0].attributes.class=o.toSvg.join(" "),o.toNode.length===0?n.removeAttribute("class"):n.setAttribute("class",o.toNode.join(" "))}var i=r.map(function(s){return tt(s)}).join(`
`);n.setAttribute(Ie,""),n.innerHTML=i}};function dr(e){e()}function ra(e,t){var n=typeof t=="function"?t:wt;if(e.length===0)n();else{var r=dr;w.mutateApproach===Ua&&(r=xe.requestAnimationFrame||dr),r(function(){var a=Fi(),o=Dn.begin("mutate");e.map(a),o(),n()})}}var _n=!1;function aa(){_n=!0}function bn(){_n=!1}var St=null;function mr(e){if(nr&&w.observeMutations){var t=e.treeCallback,n=t===void 0?wt:t,r=e.nodeCallback,a=r===void 0?wt:r,o=e.pseudoElementsCallback,i=o===void 0?wt:o,s=e.observeMutationsRoot,l=s===void 0?M:s;St=new nr(function(f){if(!_n){var u=ke();je(f).forEach(function(d){if(d.type==="childList"&&d.addedNodes.length>0&&!cr(d.addedNodes[0])&&(w.searchPseudoElements&&i(d.target),n(d.target)),d.type==="attributes"&&d.target.parentNode&&w.searchPseudoElements&&i(d.target.parentNode),d.type==="attributes"&&cr(d.target)&&~Xa.indexOf(d.attributeName))if(d.attributeName==="class"&&Ri(d.target)){var m=It($n(d.target)),b=m.prefix,p=m.iconName;d.target.setAttribute(Tn,b||u),p&&d.target.setAttribute(In,p)}else Ni(d.target)&&a(d.target)})}}),be&&St.observe(l,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}}function _i(){St&&St.disconnect()}function ji(e){var t=e.getAttribute("style"),n=[];return t&&(n=t.split(";").reduce(function(r,a){var o=a.split(":"),i=o[0],s=o.slice(1);return i&&s.length>0&&(r[i]=s.join(":").trim()),r},{})),n}function zi(e){var t=e.getAttribute("data-prefix"),n=e.getAttribute("data-icon"),r=e.innerText!==void 0?e.innerText.trim():"",a=It($n(e));return a.prefix||(a.prefix=ke()),t&&n&&(a.prefix=t,a.iconName=n),a.iconName&&a.prefix||(a.prefix&&r.length>0&&(a.iconName=bi(a.prefix,e.innerText)||Fn(a.prefix,fn(e.innerText))),!a.iconName&&w.autoFetchSvg&&e.firstChild&&e.firstChild.nodeType===Node.TEXT_NODE&&(a.iconName=e.firstChild.data)),a}function Hi(e){var t=je(e.attributes).reduce(function(a,o){return a.name!=="class"&&a.name!=="style"&&(a[o.name]=o.value),a},{}),n=e.getAttribute("title"),r=e.getAttribute("data-fa-title-id");return w.autoA11y&&(n?t["aria-labelledby"]="".concat(w.replacementClass,"-title-").concat(r||Qe()):(t["aria-hidden"]="true",t.focusable="false")),t}function Ui(){return{iconName:null,title:null,titleId:null,prefix:null,transform:ue,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function pr(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},n=zi(e),r=n.iconName,a=n.prefix,o=n.rest,i=Hi(e),s=dn("parseNodeAttributes",{},e),l=t.styleParser?ji(e):[];return y({iconName:r,title:e.getAttribute("title"),titleId:e.getAttribute("data-fa-title-id"),prefix:a,transform:ue,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:o,styles:l,attributes:i}},s)}var Yi=ae.styles;function ia(e){var t=w.autoReplaceSvg==="nest"?pr(e,{styleParser:!1}):pr(e);return~t.extra.classes.indexOf(Hr)?ge("generateLayersText",e,t):ge("generateSvgReplacementMutation",e,t)}var Ee=new Set;Cn.map(function(e){Ee.add("fa-".concat(e))});Object.keys(qe[L]).map(Ee.add.bind(Ee));Object.keys(qe[z]).map(Ee.add.bind(Ee));Ee=Ze(Ee);function vr(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!be)return Promise.resolve();var n=M.documentElement.classList,r=function(d){return n.add("".concat(rr,"-").concat(d))},a=function(d){return n.remove("".concat(rr,"-").concat(d))},o=w.autoFetchSvg?Ee:Cn.map(function(u){return"fa-".concat(u)}).concat(Object.keys(Yi));o.includes("fa")||o.push("fa");var i=[".".concat(Hr,":not([").concat(Ie,"])")].concat(o.map(function(u){return".".concat(u,":not([").concat(Ie,"])")})).join(", ");if(i.length===0)return Promise.resolve();var s=[];try{s=je(e.querySelectorAll(i))}catch{}if(s.length>0)r("pending"),a("complete");else return Promise.resolve();var l=Dn.begin("onTree"),f=s.reduce(function(u,d){try{var m=ia(d);m&&u.push(m)}catch(b){zr||b.name==="MissingIcon"&&console.error(b)}return u},[]);return new Promise(function(u,d){Promise.all(f).then(function(m){ra(m,function(){r("active"),r("complete"),a("pending"),typeof t=="function"&&t(),l(),u()})}).catch(function(m){l(),d(m)})})}function Wi(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;ia(e).then(function(n){n&&ra([n],t)})}function Bi(e){return function(t){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=(t||{}).icon?t:mn(t||{}),a=n.mask;return a&&(a=(a||{}).icon?a:mn(a||{})),e(r,y(y({},n),{},{mask:a}))}}var Gi=function(t){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=n.transform,a=r===void 0?ue:r,o=n.symbol,i=o===void 0?!1:o,s=n.mask,l=s===void 0?null:s,f=n.maskId,u=f===void 0?null:f,d=n.title,m=d===void 0?null:d,b=n.titleId,p=b===void 0?null:b,v=n.classes,h=v===void 0?[]:v,x=n.attributes,g=x===void 0?{}:x,O=n.styles,k=O===void 0?{}:O;if(t){var E=t.prefix,j=t.iconName,T=t.icon;return Ct(y({type:"icon"},t),function(){return Ce("beforeDOMElementCreation",{iconDefinition:t,params:n}),w.autoA11y&&(m?g["aria-labelledby"]="".concat(w.replacementClass,"-title-").concat(p||Qe()):(g["aria-hidden"]="true",g.focusable="false")),Mn({icons:{main:pn(T),mask:l?pn(l.icon):{found:!1,width:null,height:null,icon:{}}},prefix:E,iconName:j,transform:y(y({},ue),a),symbol:i,title:m,maskId:u,titleId:p,extra:{attributes:g,styles:k,classes:h}})})}},qi={mixout:function(){return{icon:Bi(Gi)}},hooks:function(){return{mutationObserverCallbacks:function(n){return n.treeCallback=vr,n.nodeCallback=Wi,n}}},provides:function(t){t.i2svg=function(n){var r=n.node,a=r===void 0?M:r,o=n.callback,i=o===void 0?function(){}:o;return vr(a,i)},t.generateSvgReplacementMutation=function(n,r){var a=r.iconName,o=r.title,i=r.titleId,s=r.prefix,l=r.transform,f=r.symbol,u=r.mask,d=r.maskId,m=r.extra;return new Promise(function(b,p){Promise.all([vn(a,s),u.iconName?vn(u.iconName,u.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(function(v){var h=An(v,2),x=h[0],g=h[1];b([n,Mn({icons:{main:x,mask:g},prefix:s,iconName:a,transform:l,symbol:f,maskId:d,title:o,titleId:i,extra:m,watchable:!0})])}).catch(p)})},t.generateAbstractIcon=function(n){var r=n.children,a=n.attributes,o=n.main,i=n.transform,s=n.styles,l=Ot(s);l.length>0&&(a.style=l);var f;return Rn(i)&&(f=ge("generateAbstractTransformGrouping",{main:o,transform:i,containerWidth:o.width,iconWidth:o.width})),r.push(f||o.icon),{children:r,attributes:a}}}},Vi={mixout:function(){return{layer:function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=r.classes,o=a===void 0?[]:a;return Ct({type:"layer"},function(){Ce("beforeDOMElementCreation",{assembler:n,params:r});var i=[];return n(function(s){Array.isArray(s)?s.map(function(l){i=i.concat(l.abstract)}):i=i.concat(s.abstract)}),[{tag:"span",attributes:{class:["".concat(w.cssPrefix,"-layers")].concat(Ze(o)).join(" ")},children:i}]})}}}},Xi={mixout:function(){return{counter:function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=r.title,o=a===void 0?null:a,i=r.classes,s=i===void 0?[]:i,l=r.attributes,f=l===void 0?{}:l,u=r.styles,d=u===void 0?{}:u;return Ct({type:"counter",content:n},function(){return Ce("beforeDOMElementCreation",{content:n,params:r}),Ti({content:n.toString(),title:o,extra:{attributes:f,styles:d,classes:["".concat(w.cssPrefix,"-layers-counter")].concat(Ze(s))}})})}}}},Ki={mixout:function(){return{text:function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=r.transform,o=a===void 0?ue:a,i=r.title,s=i===void 0?null:i,l=r.classes,f=l===void 0?[]:l,u=r.attributes,d=u===void 0?{}:u,m=r.styles,b=m===void 0?{}:m;return Ct({type:"text",content:n},function(){return Ce("beforeDOMElementCreation",{content:n,params:r}),ur({content:n,transform:y(y({},ue),o),title:s,extra:{attributes:d,styles:b,classes:["".concat(w.cssPrefix,"-layers-text")].concat(Ze(f))}})})}}},provides:function(t){t.generateLayersText=function(n,r){var a=r.title,o=r.transform,i=r.extra,s=null,l=null;if(Dr){var f=parseInt(getComputedStyle(n).fontSize,10),u=n.getBoundingClientRect();s=u.width/f,l=u.height/f}return w.autoA11y&&!a&&(i.attributes["aria-hidden"]="true"),Promise.resolve([n,ur({content:n.innerHTML,width:s,height:l,transform:o,title:a,extra:i,watchable:!0})])}}},Qi=new RegExp('"',"ug"),gr=[1105920,1112319];function Ji(e){var t=e.replace(Qi,""),n=ci(t,0),r=n>=gr[0]&&n<=gr[1],a=t.length===2?t[0]===t[1]:!1;return{value:fn(a?t[0]:t),isSecondary:r||a}}function br(e,t){var n="".concat(Ha).concat(t.replace(":","-"));return new Promise(function(r,a){if(e.getAttribute(n)!==null)return r();var o=je(e.children),i=o.filter(function(T){return T.getAttribute(un)===t})[0],s=xe.getComputedStyle(e,t),l=s.getPropertyValue("font-family").match(Ga),f=s.getPropertyValue("font-weight"),u=s.getPropertyValue("content");if(i&&!l)return e.removeChild(i),r();if(l&&u!=="none"&&u!==""){var d=s.getPropertyValue("content"),m=~["Sharp"].indexOf(l[2])?z:L,b=~["Solid","Regular","Light","Thin","Duotone","Brands","Kit"].indexOf(l[2])?Ve[m][l[2].toLowerCase()]:qa[m][f],p=Ji(d),v=p.value,h=p.isSecondary,x=l[0].startsWith("FontAwesome"),g=Fn(b,v),O=g;if(x){var k=hi(v);k.iconName&&k.prefix&&(g=k.iconName,b=k.prefix)}if(g&&!h&&(!i||i.getAttribute(Tn)!==b||i.getAttribute(In)!==O)){e.setAttribute(n,O),i&&e.removeChild(i);var E=Ui(),j=E.extra;j.attributes[un]=t,vn(g,b).then(function(T){var N=Mn(y(y({},E),{},{icons:{main:T,mask:Ln()},prefix:b,iconName:O,extra:j,watchable:!0})),$=M.createElement("svg");t==="::before"?e.insertBefore($,e.firstChild):e.appendChild($),$.outerHTML=N.map(function(G){return tt(G)}).join(`
`),e.removeAttribute(n),r()}).catch(a)}else r()}else r()})}function Zi(e){return Promise.all([br(e,"::before"),br(e,"::after")])}function eo(e){return e.parentNode!==document.head&&!~Ya.indexOf(e.tagName.toUpperCase())&&!e.getAttribute(un)&&(!e.parentNode||e.parentNode.tagName!=="svg")}function hr(e){if(be)return new Promise(function(t,n){var r=je(e.querySelectorAll("*")).filter(eo).map(Zi),a=Dn.begin("searchPseudoElements");aa(),Promise.all(r).then(function(){a(),bn(),t()}).catch(function(){a(),bn(),n()})})}var to={hooks:function(){return{mutationObserverCallbacks:function(n){return n.pseudoElementsCallback=hr,n}}},provides:function(t){t.pseudoElements2svg=function(n){var r=n.node,a=r===void 0?M:r;w.searchPseudoElements&&hr(a)}}},yr=!1,no={mixout:function(){return{dom:{unwatch:function(){aa(),yr=!0}}}},hooks:function(){return{bootstrap:function(){mr(dn("mutationObserverCallbacks",{}))},noAuto:function(){_i()},watch:function(n){var r=n.observeMutationsRoot;yr?bn():mr(dn("mutationObserverCallbacks",{observeMutationsRoot:r}))}}}},wr=function(t){var n={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return t.toLowerCase().split(" ").reduce(function(r,a){var o=a.toLowerCase().split("-"),i=o[0],s=o.slice(1).join("-");if(i&&s==="h")return r.flipX=!0,r;if(i&&s==="v")return r.flipY=!0,r;if(s=parseFloat(s),isNaN(s))return r;switch(i){case"grow":r.size=r.size+s;break;case"shrink":r.size=r.size-s;break;case"left":r.x=r.x-s;break;case"right":r.x=r.x+s;break;case"up":r.y=r.y-s;break;case"down":r.y=r.y+s;break;case"rotate":r.rotate=r.rotate+s;break}return r},n)},ro={mixout:function(){return{parse:{transform:function(n){return wr(n)}}}},hooks:function(){return{parseNodeAttributes:function(n,r){var a=r.getAttribute("data-fa-transform");return a&&(n.transform=wr(a)),n}}},provides:function(t){t.generateAbstractTransformGrouping=function(n){var r=n.main,a=n.transform,o=n.containerWidth,i=n.iconWidth,s={transform:"translate(".concat(o/2," 256)")},l="translate(".concat(a.x*32,", ").concat(a.y*32,") "),f="scale(".concat(a.size/16*(a.flipX?-1:1),", ").concat(a.size/16*(a.flipY?-1:1),") "),u="rotate(".concat(a.rotate," 0 0)"),d={transform:"".concat(l," ").concat(f," ").concat(u)},m={transform:"translate(".concat(i/2*-1," -256)")},b={outer:s,inner:d,path:m};return{tag:"g",attributes:y({},b.outer),children:[{tag:"g",attributes:y({},b.inner),children:[{tag:r.icon.tag,children:r.icon.children,attributes:y(y({},r.icon.attributes),b.path)}]}]}}}},Gt={x:0,y:0,width:"100%",height:"100%"};function xr(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return e.attributes&&(e.attributes.fill||t)&&(e.attributes.fill="black"),e}function ao(e){return e.tag==="g"?e.children:[e]}var io={hooks:function(){return{parseNodeAttributes:function(n,r){var a=r.getAttribute("data-fa-mask"),o=a?It(a.split(" ").map(function(i){return i.trim()})):Ln();return o.prefix||(o.prefix=ke()),n.mask=o,n.maskId=r.getAttribute("data-fa-mask-id"),n}}},provides:function(t){t.generateAbstractMask=function(n){var r=n.children,a=n.attributes,o=n.main,i=n.mask,s=n.maskId,l=n.transform,f=o.width,u=o.icon,d=i.width,m=i.icon,b=ai({transform:l,containerWidth:d,iconWidth:f}),p={tag:"rect",attributes:y(y({},Gt),{},{fill:"white"})},v=u.children?{children:u.children.map(xr)}:{},h={tag:"g",attributes:y({},b.inner),children:[xr(y({tag:u.tag,attributes:y(y({},u.attributes),b.path)},v))]},x={tag:"g",attributes:y({},b.outer),children:[h]},g="mask-".concat(s||Qe()),O="clip-".concat(s||Qe()),k={tag:"mask",attributes:y(y({},Gt),{},{id:g,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"}),children:[p,x]},E={tag:"defs",children:[{tag:"clipPath",attributes:{id:O},children:ao(m)},k]};return r.push(E,{tag:"rect",attributes:y({fill:"currentColor","clip-path":"url(#".concat(O,")"),mask:"url(#".concat(g,")")},Gt)}),{children:r,attributes:a}}}},oo={provides:function(t){var n=!1;xe.matchMedia&&(n=xe.matchMedia("(prefers-reduced-motion: reduce)").matches),t.missingIconAbstract=function(){var r=[],a={fill:"currentColor"},o={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};r.push({tag:"path",attributes:y(y({},a),{},{d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"})});var i=y(y({},o),{},{attributeName:"opacity"}),s={tag:"circle",attributes:y(y({},a),{},{cx:"256",cy:"364",r:"28"}),children:[]};return n||s.children.push({tag:"animate",attributes:y(y({},o),{},{attributeName:"r",values:"28;14;28;28;14;28;"})},{tag:"animate",attributes:y(y({},i),{},{values:"1;0;1;1;0;1;"})}),r.push(s),r.push({tag:"path",attributes:y(y({},a),{},{opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"}),children:n?[]:[{tag:"animate",attributes:y(y({},i),{},{values:"1;0;0;0;0;1;"})}]}),n||r.push({tag:"path",attributes:y(y({},a),{},{opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"}),children:[{tag:"animate",attributes:y(y({},i),{},{values:"0;0;1;1;0;0;"})}]}),{tag:"g",attributes:{class:"missing"},children:r}}}},so={hooks:function(){return{parseNodeAttributes:function(n,r){var a=r.getAttribute("data-fa-symbol"),o=a===null?!1:a===""?!0:a;return n.symbol=o,n}}}},lo=[si,qi,Vi,Xi,Ki,to,no,ro,io,oo,so];xi(lo,{mixoutsTo:ee});ee.noAuto;ee.config;ee.library;ee.dom;var hn=ee.parse;ee.findIconDefinition;ee.toHtml;var uo=ee.icon;ee.layer;ee.text;ee.counter;var qt={exports:{}},Vt,kr;function fo(){if(kr)return Vt;kr=1;var e="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";return Vt=e,Vt}var Xt,Er;function co(){if(Er)return Xt;Er=1;var e=fo();function t(){}function n(){}return n.resetWarningCache=t,Xt=function(){function r(i,s,l,f,u,d){if(d!==e){var m=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw m.name="Invariant Violation",m}}r.isRequired=r;function a(){return r}var o={array:r,bigint:r,bool:r,func:r,number:r,object:r,string:r,symbol:r,any:r,arrayOf:a,element:r,elementType:r,instanceOf:a,node:r,objectOf:a,oneOf:a,oneOfType:a,shape:a,exact:a,checkPropTypes:n,resetWarningCache:t};return o.PropTypes=o,o},Xt}var Sr;function mo(){return Sr||(Sr=1,qt.exports=co()()),qt.exports}var po=mo();const C=Ia(po);function Pr(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(a){return Object.getOwnPropertyDescriptor(e,a).enumerable})),n.push.apply(n,r)}return n}function ye(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]!=null?arguments[t]:{};t%2?Pr(Object(n),!0).forEach(function(r){Le(e,r,n[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Pr(Object(n)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(n,r))})}return e}function Pt(e){"@babel/helpers - typeof";return Pt=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Pt(e)}function Le(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function vo(e,t){if(e==null)return{};var n={},r=Object.keys(e),a,o;for(o=0;o<r.length;o++)a=r[o],!(t.indexOf(a)>=0)&&(n[a]=e[a]);return n}function go(e,t){if(e==null)return{};var n=vo(e,t),r,a;if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);for(a=0;a<o.length;a++)r=o[a],!(t.indexOf(r)>=0)&&Object.prototype.propertyIsEnumerable.call(e,r)&&(n[r]=e[r])}return n}function yn(e){return bo(e)||ho(e)||yo(e)||wo()}function bo(e){if(Array.isArray(e))return wn(e)}function ho(e){if(typeof Symbol<"u"&&e[Symbol.iterator]!=null||e["@@iterator"]!=null)return Array.from(e)}function yo(e,t){if(e){if(typeof e=="string")return wn(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if(n==="Object"&&e.constructor&&(n=e.constructor.name),n==="Map"||n==="Set")return Array.from(e);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return wn(e,t)}}function wn(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}function wo(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function xo(e){var t,n=e.beat,r=e.fade,a=e.beatFade,o=e.bounce,i=e.shake,s=e.flash,l=e.spin,f=e.spinPulse,u=e.spinReverse,d=e.pulse,m=e.fixedWidth,b=e.inverse,p=e.border,v=e.listItem,h=e.flip,x=e.size,g=e.rotation,O=e.pull,k=(t={"fa-beat":n,"fa-fade":r,"fa-beat-fade":a,"fa-bounce":o,"fa-shake":i,"fa-flash":s,"fa-spin":l,"fa-spin-reverse":u,"fa-spin-pulse":f,"fa-pulse":d,"fa-fw":m,"fa-inverse":b,"fa-border":p,"fa-li":v,"fa-flip":h===!0,"fa-flip-horizontal":h==="horizontal"||h==="both","fa-flip-vertical":h==="vertical"||h==="both"},Le(t,"fa-".concat(x),typeof x<"u"&&x!==null),Le(t,"fa-rotate-".concat(g),typeof g<"u"&&g!==null&&g!==0),Le(t,"fa-pull-".concat(O),typeof O<"u"&&O!==null),Le(t,"fa-swap-opacity",e.swapOpacity),t);return Object.keys(k).map(function(E){return k[E]?E:null}).filter(function(E){return E})}function ko(e){return e=e-0,e===e}function oa(e){return ko(e)?e:(e=e.replace(/[\-_\s]+(.)?/g,function(t,n){return n?n.toUpperCase():""}),e.substr(0,1).toLowerCase()+e.substr(1))}var Eo=["style"];function So(e){return e.charAt(0).toUpperCase()+e.slice(1)}function Po(e){return e.split(";").map(function(t){return t.trim()}).filter(function(t){return t}).reduce(function(t,n){var r=n.indexOf(":"),a=oa(n.slice(0,r)),o=n.slice(r+1).trim();return a.startsWith("webkit")?t[So(a)]=o:t[a]=o,t},{})}function sa(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof t=="string")return t;var r=(t.children||[]).map(function(l){return sa(e,l)}),a=Object.keys(t.attributes||{}).reduce(function(l,f){var u=t.attributes[f];switch(f){case"class":l.attrs.className=u,delete t.attributes.class;break;case"style":l.attrs.style=Po(u);break;default:f.indexOf("aria-")===0||f.indexOf("data-")===0?l.attrs[f.toLowerCase()]=u:l.attrs[oa(f)]=u}return l},{attrs:{}}),o=n.style,i=o===void 0?{}:o,s=go(n,Eo);return a.attrs.style=ye(ye({},a.attrs.style),i),e.apply(void 0,[t.tag,ye(ye({},a.attrs),s)].concat(yn(r)))}var la=!1;try{la=!0}catch{}function Ao(){if(!la&&console&&typeof console.error=="function"){var e;(e=console).error.apply(e,arguments)}}function Ar(e){if(e&&Pt(e)==="object"&&e.prefix&&e.iconName&&e.icon)return e;if(hn.icon)return hn.icon(e);if(e===null)return null;if(e&&Pt(e)==="object"&&e.prefix&&e.iconName)return e;if(Array.isArray(e)&&e.length===2)return{prefix:e[0],iconName:e[1]};if(typeof e=="string")return{prefix:"fas",iconName:e}}function Kt(e,t){return Array.isArray(t)&&t.length>0||!Array.isArray(t)&&t?Le({},e,t):{}}var $t=S.forwardRef(function(e,t){var n=e.icon,r=e.mask,a=e.symbol,o=e.className,i=e.title,s=e.titleId,l=e.maskId,f=Ar(n),u=Kt("classes",[].concat(yn(xo(e)),yn(o.split(" ")))),d=Kt("transform",typeof e.transform=="string"?hn.transform(e.transform):e.transform),m=Kt("mask",Ar(r)),b=uo(f,ye(ye(ye(ye({},u),d),m),{},{symbol:a,title:i,titleId:s,maskId:l}));if(!b)return Ao("Could not find icon",f),null;var p=b.abstract,v={ref:t};return Object.keys(e).forEach(function(h){$t.defaultProps.hasOwnProperty(h)||(v[h]=e[h])}),Oo(p[0],v)});$t.displayName="FontAwesomeIcon";$t.propTypes={beat:C.bool,border:C.bool,beatFade:C.bool,bounce:C.bool,className:C.string,fade:C.bool,flash:C.bool,mask:C.oneOfType([C.object,C.array,C.string]),maskId:C.string,fixedWidth:C.bool,inverse:C.bool,flip:C.oneOf([!0,!1,"horizontal","vertical","both"]),icon:C.oneOfType([C.object,C.array,C.string]),listItem:C.bool,pull:C.oneOf(["right","left"]),pulse:C.bool,rotation:C.oneOf([0,90,180,270]),shake:C.bool,size:C.oneOf(["2xs","xs","sm","lg","xl","2xl","1x","2x","3x","4x","5x","6x","7x","8x","9x","10x"]),spin:C.bool,spinPulse:C.bool,spinReverse:C.bool,symbol:C.oneOfType([C.bool,C.string]),title:C.string,titleId:C.string,transform:C.oneOfType([C.string,C.object]),swapOpacity:C.bool};$t.defaultProps={border:!1,className:"",mask:null,maskId:null,fixedWidth:!1,inverse:!1,flip:!1,icon:null,listItem:!1,pull:null,pulse:!1,rotation:null,size:null,spin:!1,spinPulse:!1,spinReverse:!1,beat:!1,fade:!1,beatFade:!1,bounce:!1,shake:!1,symbol:!1,title:"",titleId:null,transform:null,swapOpacity:!1};var Oo=sa.bind(null,S.createElement),To=Object.defineProperty,Io=(e,t,n)=>t in e?To(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,Qt=(e,t,n)=>(Io(e,typeof t!="symbol"?t+"":t,n),n);let Co=class{constructor(){Qt(this,"current",this.detect()),Qt(this,"handoffState","pending"),Qt(this,"currentId",0)}set(t){this.current!==t&&(this.handoffState="pending",this.currentId=0,this.current=t)}reset(){this.set(this.detect())}nextId(){return++this.currentId}get isServer(){return this.current==="server"}get isClient(){return this.current==="client"}detect(){return typeof window>"u"||typeof document>"u"?"server":"client"}handoff(){this.handoffState==="pending"&&(this.handoffState="complete")}get isHandoffComplete(){return this.handoffState==="complete"}},fe=new Co,V=(e,t)=>{fe.isServer?c.useEffect(e,t):c.useLayoutEffect(e,t)};function oe(e){let t=c.useRef(e);return V(()=>{t.current=e},[e]),t}function nt(e){typeof queueMicrotask=="function"?queueMicrotask(e):Promise.resolve().then(e).catch(t=>setTimeout(()=>{throw t}))}function ce(){let e=[],t={addEventListener(n,r,a,o){return n.addEventListener(r,a,o),t.add(()=>n.removeEventListener(r,a,o))},requestAnimationFrame(...n){let r=requestAnimationFrame(...n);return t.add(()=>cancelAnimationFrame(r))},nextFrame(...n){return t.requestAnimationFrame(()=>t.requestAnimationFrame(...n))},setTimeout(...n){let r=setTimeout(...n);return t.add(()=>clearTimeout(r))},microTask(...n){let r={current:!0};return nt(()=>{r.current&&n[0]()}),t.add(()=>{r.current=!1})},style(n,r,a){let o=n.style.getPropertyValue(r);return Object.assign(n.style,{[r]:a}),this.add(()=>{Object.assign(n.style,{[r]:o})})},group(n){let r=ce();return n(r),this.add(()=>r.dispose())},add(n){return e.push(n),()=>{let r=e.indexOf(n);if(r>=0)for(let a of e.splice(r,1))a()}},dispose(){for(let n of e.splice(0))n()}};return t}function rt(){let[e]=c.useState(ce);return c.useEffect(()=>()=>e.dispose(),[e]),e}let A=function(e){let t=oe(e);return S.useCallback((...n)=>t.current(...n),[t])};function ze(){let[e,t]=c.useState(fe.isHandoffComplete);return e&&fe.isHandoffComplete===!1&&t(!1),c.useEffect(()=>{e!==!0&&t(!0)},[e]),c.useEffect(()=>fe.handoff(),[]),e}var Or;let J=(Or=S.useId)!=null?Or:function(){let e=ze(),[t,n]=S.useState(e?()=>fe.nextId():null);return V(()=>{t===null&&n(fe.nextId())},[t]),t!=null?""+t:void 0};function D(e,t,...n){if(e in t){let a=t[e];return typeof a=="function"?a(...n):a}let r=new Error(`Tried to handle "${e}" but there is no handler defined. Only defined handlers are: ${Object.keys(t).map(a=>`"${a}"`).join(", ")}.`);throw Error.captureStackTrace&&Error.captureStackTrace(r,D),r}function at(e){return fe.isServer?null:e instanceof Node?e.ownerDocument:e!=null&&e.hasOwnProperty("current")&&e.current instanceof Node?e.current.ownerDocument:document}let xn=["[contentEditable=true]","[tabindex]","a[href]","area[href]","button:not([disabled])","iframe","input:not([disabled])","select:not([disabled])","textarea:not([disabled])"].map(e=>`${e}:not([tabindex='-1'])`).join(",");var X=(e=>(e[e.First=1]="First",e[e.Previous=2]="Previous",e[e.Next=4]="Next",e[e.Last=8]="Last",e[e.WrapAround=16]="WrapAround",e[e.NoScroll=32]="NoScroll",e))(X||{}),Je=(e=>(e[e.Error=0]="Error",e[e.Overflow=1]="Overflow",e[e.Success=2]="Success",e[e.Underflow=3]="Underflow",e))(Je||{}),$o=(e=>(e[e.Previous=-1]="Previous",e[e.Next=1]="Next",e))($o||{});function it(e=document.body){return e==null?[]:Array.from(e.querySelectorAll(xn)).sort((t,n)=>Math.sign((t.tabIndex||Number.MAX_SAFE_INTEGER)-(n.tabIndex||Number.MAX_SAFE_INTEGER)))}var Rt=(e=>(e[e.Strict=0]="Strict",e[e.Loose=1]="Loose",e))(Rt||{});function Nt(e,t=0){var n;return e===((n=at(e))==null?void 0:n.body)?!1:D(t,{0(){return e.matches(xn)},1(){let r=e;for(;r!==null;){if(r.matches(xn))return!0;r=r.parentElement}return!1}})}function ua(e){let t=at(e);ce().nextFrame(()=>{t&&!Nt(t.activeElement,0)&&we(e)})}function we(e){e?.focus({preventScroll:!0})}let Ro=["textarea","input"].join(",");function No(e){var t,n;return(n=(t=e?.matches)==null?void 0:t.call(e,Ro))!=null?n:!1}function fa(e,t=n=>n){return e.slice().sort((n,r)=>{let a=t(n),o=t(r);if(a===null||o===null)return 0;let i=a.compareDocumentPosition(o);return i&Node.DOCUMENT_POSITION_FOLLOWING?-1:i&Node.DOCUMENT_POSITION_PRECEDING?1:0})}function Fo(e,t){return ne(it(),t,{relativeTo:e})}function ne(e,t,{sorted:n=!0,relativeTo:r=null,skipElements:a=[]}={}){let o=Array.isArray(e)?e.length>0?e[0].ownerDocument:document:e.ownerDocument,i=Array.isArray(e)?n?fa(e):e:it(e);a.length>0&&i.length>1&&(i=i.filter(b=>!a.includes(b))),r=r??o.activeElement;let s=(()=>{if(t&5)return 1;if(t&10)return-1;throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last")})(),l=(()=>{if(t&1)return 0;if(t&2)return Math.max(0,i.indexOf(r))-1;if(t&4)return Math.max(0,i.indexOf(r))+1;if(t&8)return i.length-1;throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last")})(),f=t&32?{preventScroll:!0}:{},u=0,d=i.length,m;do{if(u>=d||u+d<=0)return 0;let b=l+u;if(t&16)b=(b+d)%d;else{if(b<0)return 3;if(b>=d)return 1}m=i[b],m?.focus(f),u+=s}while(m!==o.activeElement);return t&6&&No(m)&&m.select(),m.hasAttribute("tabindex")||m.setAttribute("tabindex","0"),2}function Jt(e,t,n){let r=oe(t);c.useEffect(()=>{function a(o){r.current(o)}return document.addEventListener(e,a,n),()=>document.removeEventListener(e,a,n)},[e,n])}function jn(e,t,n=!0){let r=c.useRef(!1);c.useEffect(()=>{requestAnimationFrame(()=>{r.current=n})},[n]);function a(i,s){if(!r.current||i.defaultPrevented)return;let l=function u(d){return typeof d=="function"?u(d()):Array.isArray(d)||d instanceof Set?d:[d]}(e),f=s(i);if(f!==null&&f.getRootNode().contains(f)){for(let u of l){if(u===null)continue;let d=u instanceof HTMLElement?u:u.current;if(d!=null&&d.contains(f)||i.composed&&i.composedPath().includes(d))return}return!Nt(f,Rt.Loose)&&f.tabIndex!==-1&&i.preventDefault(),t(i,f)}}let o=c.useRef(null);Jt("mousedown",i=>{var s,l;r.current&&(o.current=((l=(s=i.composedPath)==null?void 0:s.call(i))==null?void 0:l[0])||i.target)},!0),Jt("click",i=>{o.current&&(a(i,()=>o.current),o.current=null)},!0),Jt("blur",i=>a(i,()=>window.document.activeElement instanceof HTMLIFrameElement?window.document.activeElement:null),!0)}function Tr(e){var t;if(e.type)return e.type;let n=(t=e.as)!=null?t:"button";if(typeof n=="string"&&n.toLowerCase()==="button")return"button"}function ca(e,t){let[n,r]=c.useState(()=>Tr(e));return V(()=>{r(Tr(e))},[e.type,e.as]),V(()=>{n||t.current&&t.current instanceof HTMLButtonElement&&!t.current.hasAttribute("type")&&r("button")},[n,t]),n}let da=Symbol();function ma(e,t=!0){return Object.assign(e,{[da]:t})}function U(...e){let t=c.useRef(e);c.useEffect(()=>{t.current=e},[e]);let n=A(r=>{for(let a of t.current)a!=null&&(typeof a=="function"?a(r):a.current=r)});return e.every(r=>r==null||r?.[da])?void 0:n}function Lo({container:e,accept:t,walk:n,enabled:r=!0}){let a=c.useRef(t),o=c.useRef(n);c.useEffect(()=>{a.current=t,o.current=n},[t,n]),V(()=>{if(!e||!r)return;let i=at(e);if(!i)return;let s=a.current,l=o.current,f=Object.assign(d=>s(d),{acceptNode:s}),u=i.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,f,!1);for(;u.nextNode();)l(u.currentNode)},[e,r,a,o])}function Mo(e){throw new Error("Unexpected object: "+e)}var ie=(e=>(e[e.First=0]="First",e[e.Previous=1]="Previous",e[e.Next=2]="Next",e[e.Last=3]="Last",e[e.Specific=4]="Specific",e[e.Nothing=5]="Nothing",e))(ie||{});function Do(e,t){let n=t.resolveItems();if(n.length<=0)return null;let r=t.resolveActiveIndex(),a=r??-1,o=(()=>{switch(e.focus){case 0:return n.findIndex(i=>!t.resolveDisabled(i));case 1:{let i=n.slice().reverse().findIndex((s,l,f)=>a!==-1&&f.length-l-1>=a?!1:!t.resolveDisabled(s));return i===-1?i:n.length-1-i}case 2:return n.findIndex((i,s)=>s<=a?!1:!t.resolveDisabled(i));case 3:{let i=n.slice().reverse().findIndex(s=>!t.resolveDisabled(s));return i===-1?i:n.length-1-i}case 4:return n.findIndex(i=>t.resolveId(i)===e.id);case 5:return null;default:Mo(e)}})();return o===-1?r:o}function pa(...e){return e.filter(Boolean).join(" ")}var de=(e=>(e[e.None=0]="None",e[e.RenderStrategy=1]="RenderStrategy",e[e.Static=2]="Static",e))(de||{}),me=(e=>(e[e.Unmount=0]="Unmount",e[e.Hidden=1]="Hidden",e))(me||{});function Y({ourProps:e,theirProps:t,slot:n,defaultTag:r,features:a,visible:o=!0,name:i}){let s=va(t,e);if(o)return yt(s,n,r,i);let l=a??0;if(l&2){let{static:f=!1,...u}=s;if(f)return yt(u,n,r,i)}if(l&1){let{unmount:f=!0,...u}=s;return D(f?0:1,{0(){return null},1(){return yt({...u,hidden:!0,style:{display:"none"}},n,r,i)}})}return yt(s,n,r,i)}function yt(e,t={},n,r){var a;let{as:o=n,children:i,refName:s="ref",...l}=Zt(e,["unmount","static"]),f=e.ref!==void 0?{[s]:e.ref}:{},u=typeof i=="function"?i(t):i;"className"in l&&l.className&&typeof l.className=="function"&&(l.className=l.className(t));let d={};if(t){let m=!1,b=[];for(let[p,v]of Object.entries(t))typeof v=="boolean"&&(m=!0),v===!0&&b.push(p);m&&(d["data-headlessui-state"]=b.join(" "))}if(o===c.Fragment&&Object.keys(Ir(l)).length>0){if(!c.isValidElement(u)||Array.isArray(u)&&u.length>1)throw new Error(['Passing props on "Fragment"!',"",`The current component <${r} /> is rendering a "Fragment".`,"However we need to passthrough the following props:",Object.keys(l).map(p=>`  - ${p}`).join(`
`),"","You can apply a few solutions:",['Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".',"Render a single element as the child so that we can forward the props onto that element."].map(p=>`  - ${p}`).join(`
`)].join(`
`));let m=pa((a=u.props)==null?void 0:a.className,l.className),b=m?{className:m}:{};return c.cloneElement(u,Object.assign({},va(u.props,Ir(Zt(l,["ref"]))),d,f,_o(u.ref,f.ref),b))}return c.createElement(o,Object.assign({},Zt(l,["ref"]),o!==c.Fragment&&f,o!==c.Fragment&&d),u)}function _o(...e){return{ref:e.every(t=>t==null)?void 0:t=>{for(let n of e)n!=null&&(typeof n=="function"?n(t):n.current=t)}}}function va(...e){if(e.length===0)return{};if(e.length===1)return e[0];let t={},n={};for(let r of e)for(let a in r)a.startsWith("on")&&typeof r[a]=="function"?(n[a]!=null||(n[a]=[]),n[a].push(r[a])):t[a]=r[a];if(t.disabled||t["aria-disabled"])return Object.assign(t,Object.fromEntries(Object.keys(n).map(r=>[r,void 0])));for(let r in n)Object.assign(t,{[r](a,...o){let i=n[r];for(let s of i){if((a instanceof Event||a?.nativeEvent instanceof Event)&&a.defaultPrevented)return;s(a,...o)}}});return t}function H(e){var t;return Object.assign(c.forwardRef(e),{displayName:(t=e.displayName)!=null?t:e.name})}function Ir(e){let t=Object.assign({},e);for(let n in t)t[n]===void 0&&delete t[n];return t}function Zt(e,t=[]){let n=Object.assign({},e);for(let r of t)r in n&&delete n[r];return n}function Ft(e){let t=e.parentElement,n=null;for(;t&&!(t instanceof HTMLFieldSetElement);)t instanceof HTMLLegendElement&&(n=t),t=t.parentElement;let r=t?.getAttribute("disabled")==="";return r&&jo(n)?!1:r}function jo(e){if(!e)return!1;let t=e.previousElementSibling;for(;t!==null;){if(t instanceof HTMLLegendElement)return!1;t=t.previousElementSibling}return!0}let zo="div";var $e=(e=>(e[e.None=1]="None",e[e.Focusable=2]="Focusable",e[e.Hidden=4]="Hidden",e))($e||{});function Ho(e,t){let{features:n=1,...r}=e,a={ref:t,"aria-hidden":(n&2)===2?!0:void 0,style:{position:"fixed",top:1,left:1,width:1,height:0,padding:0,margin:-1,overflow:"hidden",clip:"rect(0, 0, 0, 0)",whiteSpace:"nowrap",borderWidth:"0",...(n&4)===4&&(n&2)!==2&&{display:"none"}}};return Y({ourProps:a,theirProps:r,slot:{},defaultTag:zo,name:"Hidden"})}let _e=H(Ho),zn=c.createContext(null);zn.displayName="OpenClosedContext";var _=(e=>(e[e.Open=1]="Open",e[e.Closed=2]="Closed",e[e.Closing=4]="Closing",e[e.Opening=8]="Opening",e))(_||{});function He(){return c.useContext(zn)}function Hn({value:e,children:t}){return S.createElement(zn.Provider,{value:e},t)}var F=(e=>(e.Space=" ",e.Enter="Enter",e.Escape="Escape",e.Backspace="Backspace",e.Delete="Delete",e.ArrowLeft="ArrowLeft",e.ArrowUp="ArrowUp",e.ArrowRight="ArrowRight",e.ArrowDown="ArrowDown",e.Home="Home",e.End="End",e.PageUp="PageUp",e.PageDown="PageDown",e.Tab="Tab",e))(F||{});function Un(e,t){let n=c.useRef([]),r=A(e);c.useEffect(()=>{let a=[...n.current];for(let[o,i]of t.entries())if(n.current[o]!==i){let s=r(t,a);return n.current=t,s}},[r,...t])}function Cr(e){return[e.screenX,e.screenY]}function Uo(){let e=c.useRef([-1,-1]);return{wasMoved(t){let n=Cr(t);return e.current[0]===n[0]&&e.current[1]===n[1]?!1:(e.current=n,!0)},update(t){e.current=Cr(t)}}}function Yo(){return/iPhone/gi.test(window.navigator.platform)||/Mac/gi.test(window.navigator.platform)&&window.navigator.maxTouchPoints>0}function Wo(e,t,n){let r=oe(t);c.useEffect(()=>{function a(o){r.current(o)}return window.addEventListener(e,a,n),()=>window.removeEventListener(e,a,n)},[e,n])}var Z=(e=>(e[e.Forwards=0]="Forwards",e[e.Backwards=1]="Backwards",e))(Z||{});function Yn(){let e=c.useRef(0);return Wo("keydown",t=>{t.key==="Tab"&&(e.current=t.shiftKey?1:0)},!0),e}function Lt(){let e=c.useRef(!1);return V(()=>(e.current=!0,()=>{e.current=!1}),[]),e}function Se(...e){return c.useMemo(()=>at(...e),[...e])}function Wn(e,t,n,r){let a=oe(n);c.useEffect(()=>{e=e??window;function o(i){a.current(i)}return e.addEventListener(t,o,r),()=>e.removeEventListener(t,o,r)},[e,t,r])}function ga(e){if(!e)return new Set;if(typeof e=="function")return new Set(e());let t=new Set;for(let n of e.current)n.current instanceof HTMLElement&&t.add(n.current);return t}let Bo="div";var ba=(e=>(e[e.None=1]="None",e[e.InitialFocus=2]="InitialFocus",e[e.TabLock=4]="TabLock",e[e.FocusLock=8]="FocusLock",e[e.RestoreFocus=16]="RestoreFocus",e[e.All=30]="All",e))(ba||{});function Go(e,t){let n=c.useRef(null),r=U(n,t),{initialFocus:a,containers:o,features:i=30,...s}=e;ze()||(i=1);let l=Se(n);Xo({ownerDocument:l},!!(i&16));let f=Ko({ownerDocument:l,container:n,initialFocus:a},!!(i&2));Qo({ownerDocument:l,container:n,containers:o,previousActiveElement:f},!!(i&8));let u=Yn(),d=A(v=>{let h=n.current;h&&(x=>x())(()=>{D(u.current,{[Z.Forwards]:()=>{ne(h,X.First,{skipElements:[v.relatedTarget]})},[Z.Backwards]:()=>{ne(h,X.Last,{skipElements:[v.relatedTarget]})}})})}),m=rt(),b=c.useRef(!1),p={ref:r,onKeyDown(v){v.key=="Tab"&&(b.current=!0,m.requestAnimationFrame(()=>{b.current=!1}))},onBlur(v){let h=ga(o);n.current instanceof HTMLElement&&h.add(n.current);let x=v.relatedTarget;x instanceof HTMLElement&&x.dataset.headlessuiFocusGuard!=="true"&&(ha(h,x)||(b.current?ne(n.current,D(u.current,{[Z.Forwards]:()=>X.Next,[Z.Backwards]:()=>X.Previous})|X.WrapAround,{relativeTo:v.target}):v.target instanceof HTMLElement&&we(v.target)))}};return S.createElement(S.Fragment,null,!!(i&4)&&S.createElement(_e,{as:"button",type:"button","data-headlessui-focus-guard":!0,onFocus:d,features:$e.Focusable}),Y({ourProps:p,theirProps:s,defaultTag:Bo,name:"FocusTrap"}),!!(i&4)&&S.createElement(_e,{as:"button",type:"button","data-headlessui-focus-guard":!0,onFocus:d,features:$e.Focusable}))}let qo=H(Go),Ue=Object.assign(qo,{features:ba}),he=[];if(typeof window<"u"&&typeof document<"u"){let e=function(t){t.target instanceof HTMLElement&&t.target!==document.body&&he[0]!==t.target&&(he.unshift(t.target),he=he.filter(n=>n!=null&&n.isConnected),he.splice(10))};window.addEventListener("click",e,{capture:!0}),window.addEventListener("mousedown",e,{capture:!0}),window.addEventListener("focus",e,{capture:!0}),document.body.addEventListener("click",e,{capture:!0}),document.body.addEventListener("mousedown",e,{capture:!0}),document.body.addEventListener("focus",e,{capture:!0})}function Vo(e=!0){let t=c.useRef(he.slice());return Un(([n],[r])=>{r===!0&&n===!1&&nt(()=>{t.current.splice(0)}),r===!1&&n===!0&&(t.current=he.slice())},[e,he,t]),A(()=>{var n;return(n=t.current.find(r=>r!=null&&r.isConnected))!=null?n:null})}function Xo({ownerDocument:e},t){let n=Vo(t);Un(()=>{t||e?.activeElement===e?.body&&we(n())},[t]);let r=c.useRef(!1);c.useEffect(()=>(r.current=!1,()=>{r.current=!0,nt(()=>{r.current&&we(n())})}),[])}function Ko({ownerDocument:e,container:t,initialFocus:n},r){let a=c.useRef(null),o=Lt();return Un(()=>{if(!r)return;let i=t.current;i&&nt(()=>{if(!o.current)return;let s=e?.activeElement;if(n!=null&&n.current){if(n?.current===s){a.current=s;return}}else if(i.contains(s)){a.current=s;return}n!=null&&n.current?we(n.current):ne(i,X.First)===Je.Error&&console.warn("There are no focusable elements inside the <FocusTrap />"),a.current=e?.activeElement})},[r]),a}function Qo({ownerDocument:e,container:t,containers:n,previousActiveElement:r},a){let o=Lt();Wn(e?.defaultView,"focus",i=>{if(!a||!o.current)return;let s=ga(n);t.current instanceof HTMLElement&&s.add(t.current);let l=r.current;if(!l)return;let f=i.target;f&&f instanceof HTMLElement?ha(s,f)?(r.current=f,we(f)):(i.preventDefault(),i.stopPropagation(),we(l)):we(r.current)},!0)}function ha(e,t){for(let n of e)if(n.contains(t))return!0;return!1}let ya=c.createContext(!1);function Jo(){return c.useContext(ya)}function kn(e){return S.createElement(ya.Provider,{value:e.force},e.children)}function Zo(e){let t=Jo(),n=c.useContext(wa),r=Se(e),[a,o]=c.useState(()=>{if(!t&&n!==null||fe.isServer)return null;let i=r?.getElementById("headlessui-portal-root");if(i)return i;if(r===null)return null;let s=r.createElement("div");return s.setAttribute("id","headlessui-portal-root"),r.body.appendChild(s)});return c.useEffect(()=>{a!==null&&(r!=null&&r.body.contains(a)||r==null||r.body.appendChild(a))},[a,r]),c.useEffect(()=>{t||n!==null&&o(n.current)},[n,o,t]),a}let es=c.Fragment;function ts(e,t){let n=e,r=c.useRef(null),a=U(ma(u=>{r.current=u}),t),o=Se(r),i=Zo(r),[s]=c.useState(()=>{var u;return fe.isServer?null:(u=o?.createElement("div"))!=null?u:null}),l=ze(),f=c.useRef(!1);return V(()=>{if(f.current=!1,!(!i||!s))return i.contains(s)||(s.setAttribute("data-headlessui-portal",""),i.appendChild(s)),()=>{f.current=!0,nt(()=>{var u;f.current&&(!i||!s||(s instanceof Node&&i.contains(s)&&i.removeChild(s),i.childNodes.length<=0&&((u=i.parentElement)==null||u.removeChild(i))))})}},[i,s]),l?!i||!s?null:Ca.createPortal(Y({ourProps:{ref:a},theirProps:n,defaultTag:es,name:"Portal"}),s):null}let ns=c.Fragment,wa=c.createContext(null);function rs(e,t){let{target:n,...r}=e,a={ref:U(t)};return S.createElement(wa.Provider,{value:n},Y({ourProps:a,theirProps:r,defaultTag:ns,name:"Popover.Group"}))}let as=H(ts),is=H(rs),En=Object.assign(as,{Group:is}),xa=c.createContext(null);function ka(){let e=c.useContext(xa);if(e===null){let t=new Error("You used a <Description /> component, but it is not inside a relevant parent.");throw Error.captureStackTrace&&Error.captureStackTrace(t,ka),t}return e}function os(){let[e,t]=c.useState([]);return[e.length>0?e.join(" "):void 0,c.useMemo(()=>function(n){let r=A(o=>(t(i=>[...i,o]),()=>t(i=>{let s=i.slice(),l=s.indexOf(o);return l!==-1&&s.splice(l,1),s}))),a=c.useMemo(()=>({register:r,slot:n.slot,name:n.name,props:n.props}),[r,n.slot,n.name,n.props]);return S.createElement(xa.Provider,{value:a},n.children)},[t])]}let ss="p";function ls(e,t){let n=J(),{id:r=`headlessui-description-${n}`,...a}=e,o=ka(),i=U(t);V(()=>o.register(r),[r,o.register]);let s={ref:i,...o.props,id:r};return Y({ourProps:s,theirProps:a,slot:o.slot||{},defaultTag:ss,name:o.name||"Description"})}let us=H(ls),fs=Object.assign(us,{}),Bn=c.createContext(()=>{});Bn.displayName="StackContext";var Sn=(e=>(e[e.Add=0]="Add",e[e.Remove=1]="Remove",e))(Sn||{});function cs(){return c.useContext(Bn)}function ds({children:e,onUpdate:t,type:n,element:r,enabled:a}){let o=cs(),i=A((...s)=>{t?.(...s),o(...s)});return V(()=>{let s=a===void 0||a===!0;return s&&i(0,n,r),()=>{s&&i(1,n,r)}},[i,n,r,a]),S.createElement(Bn.Provider,{value:i},e)}function ms(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}const ps=typeof Object.is=="function"?Object.is:ms,{useState:vs,useEffect:gs,useLayoutEffect:bs,useDebugValue:hs}=on;function ys(e,t,n){const r=t(),[{inst:a},o]=vs({inst:{value:r,getSnapshot:t}});return bs(()=>{a.value=r,a.getSnapshot=t,en(a)&&o({inst:a})},[e,r,t]),gs(()=>(en(a)&&o({inst:a}),e(()=>{en(a)&&o({inst:a})})),[e]),hs(r),r}function en(e){const t=e.getSnapshot,n=e.value;try{const r=t();return!ps(n,r)}catch{return!0}}function ws(e,t,n){return t()}const xs=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u",ks=!xs,Es=ks?ws:ys,Ss="useSyncExternalStore"in on?(e=>e.useSyncExternalStore)(on):Es;function Ps(e){return Ss(e.subscribe,e.getSnapshot,e.getSnapshot)}function As(e,t){let n=e(),r=new Set;return{getSnapshot(){return n},subscribe(a){return r.add(a),()=>r.delete(a)},dispatch(a,...o){let i=t[a].call(n,...o);i&&(n=i,r.forEach(s=>s()))}}}function Os(){let e;return{before({doc:t}){var n;let r=t.documentElement;e=((n=t.defaultView)!=null?n:window).innerWidth-r.clientWidth},after({doc:t,d:n}){let r=t.documentElement,a=r.clientWidth-r.offsetWidth,o=e-a;n.style(r,"paddingRight",`${o}px`)}}}function Ts(){if(!Yo())return{};let e;return{before(){e=window.pageYOffset},after({doc:t,d:n,meta:r}){function a(i){return r.containers.flatMap(s=>s()).some(s=>s.contains(i))}n.style(t.body,"marginTop",`-${e}px`),window.scrollTo(0,0);let o=null;n.addEventListener(t,"click",i=>{if(i.target instanceof HTMLElement)try{let s=i.target.closest("a");if(!s)return;let{hash:l}=new URL(s.href),f=t.querySelector(l);f&&!a(f)&&(o=f)}catch{}},!0),n.addEventListener(t,"touchmove",i=>{i.target instanceof HTMLElement&&!a(i.target)&&i.preventDefault()},{passive:!1}),n.add(()=>{window.scrollTo(0,window.pageYOffset+e),o&&o.isConnected&&(o.scrollIntoView({block:"nearest"}),o=null)})}}}function Is(){return{before({doc:e,d:t}){t.style(e.documentElement,"overflow","hidden")}}}function Cs(e){let t={};for(let n of e)Object.assign(t,n(t));return t}let Te=As(()=>new Map,{PUSH(e,t){var n;let r=(n=this.get(e))!=null?n:{doc:e,count:0,d:ce(),meta:new Set};return r.count++,r.meta.add(t),this.set(e,r),this},POP(e,t){let n=this.get(e);return n&&(n.count--,n.meta.delete(t)),this},SCROLL_PREVENT({doc:e,d:t,meta:n}){let r={doc:e,d:t,meta:Cs(n)},a=[Ts(),Os(),Is()];a.forEach(({before:o})=>o?.(r)),a.forEach(({after:o})=>o?.(r))},SCROLL_ALLOW({d:e}){e.dispose()},TEARDOWN({doc:e}){this.delete(e)}});Te.subscribe(()=>{let e=Te.getSnapshot(),t=new Map;for(let[n]of e)t.set(n,n.documentElement.style.overflow);for(let n of e.values()){let r=t.get(n.doc)==="hidden",a=n.count!==0;(a&&!r||!a&&r)&&Te.dispatch(n.count>0?"SCROLL_PREVENT":"SCROLL_ALLOW",n),n.count===0&&Te.dispatch("TEARDOWN",n)}});function $s(e,t,n){let r=Ps(Te),a=e?r.get(e):void 0,o=a?a.count>0:!1;return V(()=>{if(!(!e||!t))return Te.dispatch("PUSH",e,n),()=>Te.dispatch("POP",e,n)},[t,e]),o}let tn=new Map,Ye=new Map;function $r(e,t=!0){V(()=>{var n;if(!t)return;let r=typeof e=="function"?e():e.current;if(!r)return;function a(){var i;if(!r)return;let s=(i=Ye.get(r))!=null?i:1;if(s===1?Ye.delete(r):Ye.set(r,s-1),s!==1)return;let l=tn.get(r);l&&(l["aria-hidden"]===null?r.removeAttribute("aria-hidden"):r.setAttribute("aria-hidden",l["aria-hidden"]),r.inert=l.inert,tn.delete(r))}let o=(n=Ye.get(r))!=null?n:0;return Ye.set(r,o+1),o!==0||(tn.set(r,{"aria-hidden":r.getAttribute("aria-hidden"),inert:r.inert}),r.setAttribute("aria-hidden","true"),r.inert=!0),a},[e,t])}var Rs=(e=>(e[e.Open=0]="Open",e[e.Closed=1]="Closed",e))(Rs||{}),Ns=(e=>(e[e.SetTitleId=0]="SetTitleId",e))(Ns||{});let Fs={0(e,t){return e.titleId===t.id?e:{...e,titleId:t.id}}},At=c.createContext(null);At.displayName="DialogContext";function ot(e){let t=c.useContext(At);if(t===null){let n=new Error(`<${e} /> is missing a parent <Dialog /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(n,ot),n}return t}function Ls(e,t,n=()=>[document.body]){$s(e,t,r=>{var a;return{containers:[...(a=r.containers)!=null?a:[],n]}})}function Ms(e,t){return D(t.type,Fs,e,t)}let Ds="div",_s=de.RenderStrategy|de.Static;function js(e,t){let n=J(),{id:r=`headlessui-dialog-${n}`,open:a,onClose:o,initialFocus:i,__demoMode:s=!1,...l}=e,[f,u]=c.useState(0),d=He();a===void 0&&d!==null&&(a=(d&_.Open)===_.Open);let m=c.useRef(null),b=U(m,t),p=c.useRef(null),v=Se(m),h=e.hasOwnProperty("open")||d!==null,x=e.hasOwnProperty("onClose");if(!h&&!x)throw new Error("You have to provide an `open` and an `onClose` prop to the `Dialog` component.");if(!h)throw new Error("You provided an `onClose` prop to the `Dialog`, but forgot an `open` prop.");if(!x)throw new Error("You provided an `open` prop to the `Dialog`, but forgot an `onClose` prop.");if(typeof a!="boolean")throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${a}`);if(typeof o!="function")throw new Error(`You provided an \`onClose\` prop to the \`Dialog\`, but the value is not a function. Received: ${o}`);let g=a?0:1,[O,k]=c.useReducer(Ms,{titleId:null,descriptionId:null,panelRef:c.createRef()}),E=A(()=>o(!1)),j=A(W=>k({type:0,id:W})),T=ze()?s?!1:g===0:!1,N=f>1,$=c.useContext(At)!==null,G=N?"parent":"leaf",I=d!==null?(d&_.Closing)===_.Closing:!1,P=$||I?!1:T,R=c.useCallback(()=>{var W,te;return(te=Array.from((W=v?.querySelectorAll("body > *"))!=null?W:[]).find(q=>q.id==="headlessui-portal-root"?!1:q.contains(p.current)&&q instanceof HTMLElement))!=null?te:null},[p]);$r(R,P);let Q=N?!0:T,K=c.useCallback(()=>{var W,te;return(te=Array.from((W=v?.querySelectorAll("[data-headlessui-portal]"))!=null?W:[]).find(q=>q.contains(p.current)&&q instanceof HTMLElement))!=null?te:null},[p]);$r(K,Q);let se=A(()=>{var W,te;return[...Array.from((W=v?.querySelectorAll("html > *, body > *, [data-headlessui-portal]"))!=null?W:[]).filter(q=>!(q===document.body||q===document.head||!(q instanceof HTMLElement)||q.contains(p.current)||O.panelRef.current&&q.contains(O.panelRef.current))),(te=O.panelRef.current)!=null?te:m.current]});jn(()=>se(),E,!(!T||N));let re=!(N||g!==0);Wn(v?.defaultView,"keydown",W=>{re&&(W.defaultPrevented||W.key===F.Escape&&(W.preventDefault(),W.stopPropagation(),E()))}),Ls(v,!(I||g!==0||$),se),c.useEffect(()=>{if(g!==0||!m.current)return;let W=new ResizeObserver(te=>{for(let q of te){let ut=q.target.getBoundingClientRect();ut.x===0&&ut.y===0&&ut.width===0&&ut.height===0&&E()}});return W.observe(m.current),()=>W.disconnect()},[g,m,E]);let[Ut,le]=os(),Oa=c.useMemo(()=>[{dialogState:g,close:E,setTitleId:j},O],[g,O,E,j]),Qn=c.useMemo(()=>({open:g===0}),[g]),Ta={ref:b,id:r,role:"dialog","aria-modal":g===0?!0:void 0,"aria-labelledby":O.titleId,"aria-describedby":Ut};return S.createElement(ds,{type:"Dialog",enabled:g===0,element:m,onUpdate:A((W,te)=>{te==="Dialog"&&D(W,{[Sn.Add]:()=>u(q=>q+1),[Sn.Remove]:()=>u(q=>q-1)})})},S.createElement(kn,{force:!0},S.createElement(En,null,S.createElement(At.Provider,{value:Oa},S.createElement(En.Group,{target:m},S.createElement(kn,{force:!1},S.createElement(le,{slot:Qn,name:"Dialog.Description"},S.createElement(Ue,{initialFocus:i,containers:se,features:T?D(G,{parent:Ue.features.RestoreFocus,leaf:Ue.features.All&~Ue.features.FocusLock}):Ue.features.None},Y({ourProps:Ta,theirProps:l,slot:Qn,defaultTag:Ds,features:_s,visible:g===0,name:"Dialog"})))))))),S.createElement(_e,{features:$e.Hidden,ref:p}))}let zs="div";function Hs(e,t){let n=J(),{id:r=`headlessui-dialog-overlay-${n}`,...a}=e,[{dialogState:o,close:i}]=ot("Dialog.Overlay"),s=U(t),l=A(u=>{if(u.target===u.currentTarget){if(Ft(u.currentTarget))return u.preventDefault();u.preventDefault(),u.stopPropagation(),i()}}),f=c.useMemo(()=>({open:o===0}),[o]);return Y({ourProps:{ref:s,id:r,"aria-hidden":!0,onClick:l},theirProps:a,slot:f,defaultTag:zs,name:"Dialog.Overlay"})}let Us="div";function Ys(e,t){let n=J(),{id:r=`headlessui-dialog-backdrop-${n}`,...a}=e,[{dialogState:o},i]=ot("Dialog.Backdrop"),s=U(t);c.useEffect(()=>{if(i.panelRef.current===null)throw new Error("A <Dialog.Backdrop /> component is being used, but a <Dialog.Panel /> component is missing.")},[i.panelRef]);let l=c.useMemo(()=>({open:o===0}),[o]);return S.createElement(kn,{force:!0},S.createElement(En,null,Y({ourProps:{ref:s,id:r,"aria-hidden":!0},theirProps:a,slot:l,defaultTag:Us,name:"Dialog.Backdrop"})))}let Ws="div";function Bs(e,t){let n=J(),{id:r=`headlessui-dialog-panel-${n}`,...a}=e,[{dialogState:o},i]=ot("Dialog.Panel"),s=U(t,i.panelRef),l=c.useMemo(()=>({open:o===0}),[o]),f=A(u=>{u.stopPropagation()});return Y({ourProps:{ref:s,id:r,onClick:f},theirProps:a,slot:l,defaultTag:Ws,name:"Dialog.Panel"})}let Gs="h2";function qs(e,t){let n=J(),{id:r=`headlessui-dialog-title-${n}`,...a}=e,[{dialogState:o,setTitleId:i}]=ot("Dialog.Title"),s=U(t);c.useEffect(()=>(i(r),()=>i(null)),[r,i]);let l=c.useMemo(()=>({open:o===0}),[o]);return Y({ourProps:{ref:s,id:r},theirProps:a,slot:l,defaultTag:Gs,name:"Dialog.Title"})}let Vs=H(js),Xs=H(Ys),Ks=H(Bs),Qs=H(Hs),Js=H(qs),iu=Object.assign(Vs,{Backdrop:Xs,Panel:Ks,Overlay:Qs,Title:Js,Description:fs});var Zs=(e=>(e[e.Open=0]="Open",e[e.Closed=1]="Closed",e))(Zs||{}),el=(e=>(e[e.Pointer=0]="Pointer",e[e.Other=1]="Other",e))(el||{}),tl=(e=>(e[e.OpenMenu=0]="OpenMenu",e[e.CloseMenu=1]="CloseMenu",e[e.GoToItem=2]="GoToItem",e[e.Search=3]="Search",e[e.ClearSearch=4]="ClearSearch",e[e.RegisterItem=5]="RegisterItem",e[e.UnregisterItem=6]="UnregisterItem",e))(tl||{});function nn(e,t=n=>n){let n=e.activeItemIndex!==null?e.items[e.activeItemIndex]:null,r=fa(t(e.items.slice()),o=>o.dataRef.current.domRef.current),a=n?r.indexOf(n):null;return a===-1&&(a=null),{items:r,activeItemIndex:a}}let nl={1(e){return e.menuState===1?e:{...e,activeItemIndex:null,menuState:1}},0(e){return e.menuState===0?e:{...e,menuState:0}},2:(e,t)=>{var n;let r=nn(e),a=Do(t,{resolveItems:()=>r.items,resolveActiveIndex:()=>r.activeItemIndex,resolveId:o=>o.id,resolveDisabled:o=>o.dataRef.current.disabled});return{...e,...r,searchQuery:"",activeItemIndex:a,activationTrigger:(n=t.trigger)!=null?n:1}},3:(e,t)=>{let n=e.searchQuery!==""?0:1,r=e.searchQuery+t.value.toLowerCase(),a=(e.activeItemIndex!==null?e.items.slice(e.activeItemIndex+n).concat(e.items.slice(0,e.activeItemIndex+n)):e.items).find(i=>{var s;return((s=i.dataRef.current.textValue)==null?void 0:s.startsWith(r))&&!i.dataRef.current.disabled}),o=a?e.items.indexOf(a):-1;return o===-1||o===e.activeItemIndex?{...e,searchQuery:r}:{...e,searchQuery:r,activeItemIndex:o,activationTrigger:1}},4(e){return e.searchQuery===""?e:{...e,searchQuery:"",searchActiveItemIndex:null}},5:(e,t)=>{let n=nn(e,r=>[...r,{id:t.id,dataRef:t.dataRef}]);return{...e,...n}},6:(e,t)=>{let n=nn(e,r=>{let a=r.findIndex(o=>o.id===t.id);return a!==-1&&r.splice(a,1),r});return{...e,...n,activationTrigger:1}}},Gn=c.createContext(null);Gn.displayName="MenuContext";function Mt(e){let t=c.useContext(Gn);if(t===null){let n=new Error(`<${e} /> is missing a parent <Menu /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(n,Mt),n}return t}function rl(e,t){return D(t.type,nl,e,t)}let al=c.Fragment;function il(e,t){let n=c.useReducer(rl,{menuState:1,buttonRef:c.createRef(),itemsRef:c.createRef(),items:[],searchQuery:"",activeItemIndex:null,activationTrigger:1}),[{menuState:r,itemsRef:a,buttonRef:o},i]=n,s=U(t);jn([o,a],(m,b)=>{var p;i({type:1}),Nt(b,Rt.Loose)||(m.preventDefault(),(p=o.current)==null||p.focus())},r===0);let l=A(()=>{i({type:1})}),f=c.useMemo(()=>({open:r===0,close:l}),[r,l]),u=e,d={ref:s};return S.createElement(Gn.Provider,{value:n},S.createElement(Hn,{value:D(r,{0:_.Open,1:_.Closed})},Y({ourProps:d,theirProps:u,slot:f,defaultTag:al,name:"Menu"})))}let ol="button";function sl(e,t){var n;let r=J(),{id:a=`headlessui-menu-button-${r}`,...o}=e,[i,s]=Mt("Menu.Button"),l=U(i.buttonRef,t),f=rt(),u=A(v=>{switch(v.key){case F.Space:case F.Enter:case F.ArrowDown:v.preventDefault(),v.stopPropagation(),s({type:0}),f.nextFrame(()=>s({type:2,focus:ie.First}));break;case F.ArrowUp:v.preventDefault(),v.stopPropagation(),s({type:0}),f.nextFrame(()=>s({type:2,focus:ie.Last}));break}}),d=A(v=>{switch(v.key){case F.Space:v.preventDefault();break}}),m=A(v=>{if(Ft(v.currentTarget))return v.preventDefault();e.disabled||(i.menuState===0?(s({type:1}),f.nextFrame(()=>{var h;return(h=i.buttonRef.current)==null?void 0:h.focus({preventScroll:!0})})):(v.preventDefault(),s({type:0})))}),b=c.useMemo(()=>({open:i.menuState===0}),[i]),p={ref:l,id:a,type:ca(e,i.buttonRef),"aria-haspopup":"menu","aria-controls":(n=i.itemsRef.current)==null?void 0:n.id,"aria-expanded":e.disabled?void 0:i.menuState===0,onKeyDown:u,onKeyUp:d,onClick:m};return Y({ourProps:p,theirProps:o,slot:b,defaultTag:ol,name:"Menu.Button"})}let ll="div",ul=de.RenderStrategy|de.Static;function fl(e,t){var n,r;let a=J(),{id:o=`headlessui-menu-items-${a}`,...i}=e,[s,l]=Mt("Menu.Items"),f=U(s.itemsRef,t),u=Se(s.itemsRef),d=rt(),m=He(),b=m!==null?(m&_.Open)===_.Open:s.menuState===0;c.useEffect(()=>{let g=s.itemsRef.current;g&&s.menuState===0&&g!==u?.activeElement&&g.focus({preventScroll:!0})},[s.menuState,s.itemsRef,u]),Lo({container:s.itemsRef.current,enabled:s.menuState===0,accept(g){return g.getAttribute("role")==="menuitem"?NodeFilter.FILTER_REJECT:g.hasAttribute("role")?NodeFilter.FILTER_SKIP:NodeFilter.FILTER_ACCEPT},walk(g){g.setAttribute("role","none")}});let p=A(g=>{var O,k;switch(d.dispose(),g.key){case F.Space:if(s.searchQuery!=="")return g.preventDefault(),g.stopPropagation(),l({type:3,value:g.key});case F.Enter:if(g.preventDefault(),g.stopPropagation(),l({type:1}),s.activeItemIndex!==null){let{dataRef:E}=s.items[s.activeItemIndex];(k=(O=E.current)==null?void 0:O.domRef.current)==null||k.click()}ua(s.buttonRef.current);break;case F.ArrowDown:return g.preventDefault(),g.stopPropagation(),l({type:2,focus:ie.Next});case F.ArrowUp:return g.preventDefault(),g.stopPropagation(),l({type:2,focus:ie.Previous});case F.Home:case F.PageUp:return g.preventDefault(),g.stopPropagation(),l({type:2,focus:ie.First});case F.End:case F.PageDown:return g.preventDefault(),g.stopPropagation(),l({type:2,focus:ie.Last});case F.Escape:g.preventDefault(),g.stopPropagation(),l({type:1}),ce().nextFrame(()=>{var E;return(E=s.buttonRef.current)==null?void 0:E.focus({preventScroll:!0})});break;case F.Tab:g.preventDefault(),g.stopPropagation(),l({type:1}),ce().nextFrame(()=>{Fo(s.buttonRef.current,g.shiftKey?X.Previous:X.Next)});break;default:g.key.length===1&&(l({type:3,value:g.key}),d.setTimeout(()=>l({type:4}),350));break}}),v=A(g=>{switch(g.key){case F.Space:g.preventDefault();break}}),h=c.useMemo(()=>({open:s.menuState===0}),[s]),x={"aria-activedescendant":s.activeItemIndex===null||(n=s.items[s.activeItemIndex])==null?void 0:n.id,"aria-labelledby":(r=s.buttonRef.current)==null?void 0:r.id,id:o,onKeyDown:p,onKeyUp:v,role:"menu",tabIndex:0,ref:f};return Y({ourProps:x,theirProps:i,slot:h,defaultTag:ll,features:ul,visible:b,name:"Menu.Items"})}let cl=c.Fragment;function dl(e,t){let n=J(),{id:r=`headlessui-menu-item-${n}`,disabled:a=!1,...o}=e,[i,s]=Mt("Menu.Item"),l=i.activeItemIndex!==null?i.items[i.activeItemIndex].id===r:!1,f=c.useRef(null),u=U(t,f);V(()=>{if(i.menuState!==0||!l||i.activationTrigger===0)return;let k=ce();return k.requestAnimationFrame(()=>{var E,j;(j=(E=f.current)==null?void 0:E.scrollIntoView)==null||j.call(E,{block:"nearest"})}),k.dispose},[f,l,i.menuState,i.activationTrigger,i.activeItemIndex]);let d=c.useRef({disabled:a,domRef:f});V(()=>{d.current.disabled=a},[d,a]),V(()=>{var k,E;d.current.textValue=(E=(k=f.current)==null?void 0:k.textContent)==null?void 0:E.toLowerCase()},[d,f]),V(()=>(s({type:5,id:r,dataRef:d}),()=>s({type:6,id:r})),[d,r]);let m=A(()=>{s({type:1})}),b=A(k=>{if(a)return k.preventDefault();s({type:1}),ua(i.buttonRef.current)}),p=A(()=>{if(a)return s({type:2,focus:ie.Nothing});s({type:2,focus:ie.Specific,id:r})}),v=Uo(),h=A(k=>v.update(k)),x=A(k=>{v.wasMoved(k)&&(a||l||s({type:2,focus:ie.Specific,id:r,trigger:0}))}),g=A(k=>{v.wasMoved(k)&&(a||l&&s({type:2,focus:ie.Nothing}))}),O=c.useMemo(()=>({active:l,disabled:a,close:m}),[l,a,m]);return Y({ourProps:{id:r,ref:u,role:"menuitem",tabIndex:a===!0?void 0:-1,"aria-disabled":a===!0?!0:void 0,disabled:void 0,onClick:b,onFocus:p,onPointerEnter:h,onMouseEnter:h,onPointerMove:x,onMouseMove:x,onPointerLeave:g,onMouseLeave:g},theirProps:o,slot:O,defaultTag:cl,name:"Menu.Item"})}let ml=H(il),pl=H(sl),vl=H(fl),gl=H(dl),ou=Object.assign(ml,{Button:pl,Items:vl,Item:gl});var bl=(e=>(e[e.Open=0]="Open",e[e.Closed=1]="Closed",e))(bl||{}),hl=(e=>(e[e.TogglePopover=0]="TogglePopover",e[e.ClosePopover=1]="ClosePopover",e[e.SetButton=2]="SetButton",e[e.SetButtonId=3]="SetButtonId",e[e.SetPanel=4]="SetPanel",e[e.SetPanelId=5]="SetPanelId",e))(hl||{});let yl={0:e=>({...e,popoverState:D(e.popoverState,{0:1,1:0})}),1(e){return e.popoverState===1?e:{...e,popoverState:1}},2(e,t){return e.button===t.button?e:{...e,button:t.button}},3(e,t){return e.buttonId===t.buttonId?e:{...e,buttonId:t.buttonId}},4(e,t){return e.panel===t.panel?e:{...e,panel:t.panel}},5(e,t){return e.panelId===t.panelId?e:{...e,panelId:t.panelId}}},qn=c.createContext(null);qn.displayName="PopoverContext";function Dt(e){let t=c.useContext(qn);if(t===null){let n=new Error(`<${e} /> is missing a parent <Popover /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(n,Dt),n}return t}let Vn=c.createContext(null);Vn.displayName="PopoverAPIContext";function Xn(e){let t=c.useContext(Vn);if(t===null){let n=new Error(`<${e} /> is missing a parent <Popover /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(n,Xn),n}return t}let Kn=c.createContext(null);Kn.displayName="PopoverGroupContext";function Ea(){return c.useContext(Kn)}let _t=c.createContext(null);_t.displayName="PopoverPanelContext";function wl(){return c.useContext(_t)}function xl(e,t){return D(t.type,yl,e,t)}let kl="div";function El(e,t){var n;let r=c.useRef(null),a=U(t,ma(P=>{r.current=P})),o=c.useRef([]),i=c.useReducer(xl,{popoverState:1,buttons:o,button:null,buttonId:null,panel:null,panelId:null,beforePanelSentinel:c.createRef(),afterPanelSentinel:c.createRef()}),[{popoverState:s,button:l,buttonId:f,panel:u,panelId:d,beforePanelSentinel:m,afterPanelSentinel:b},p]=i,v=Se((n=r.current)!=null?n:l),h=c.useMemo(()=>{if(!l||!u)return!1;for(let re of document.querySelectorAll("body > *"))if(Number(re?.contains(l))^Number(re?.contains(u)))return!0;let P=it(),R=P.indexOf(l),Q=(R+P.length-1)%P.length,K=(R+1)%P.length,se=P[Q],st=P[K];return!u.contains(se)&&!u.contains(st)},[l,u]),x=oe(f),g=oe(d),O=c.useMemo(()=>({buttonId:x,panelId:g,close:()=>p({type:1})}),[x,g,p]),k=Ea(),E=k?.registerPopover,j=A(()=>{var P;return(P=k?.isFocusWithinPopoverGroup())!=null?P:v?.activeElement&&(l?.contains(v.activeElement)||u?.contains(v.activeElement))});c.useEffect(()=>E?.(O),[E,O]),Wn(v?.defaultView,"focus",P=>{var R,Q,K,se;s===0&&(j()||l&&u&&P.target!==window&&((Q=(R=m.current)==null?void 0:R.contains)!=null&&Q.call(R,P.target)||(se=(K=b.current)==null?void 0:K.contains)!=null&&se.call(K,P.target)||p({type:1})))},!0),jn([l,u],(P,R)=>{p({type:1}),Nt(R,Rt.Loose)||(P.preventDefault(),l?.focus())},s===0);let T=A(P=>{p({type:1});let R=P?P instanceof HTMLElement?P:"current"in P&&P.current instanceof HTMLElement?P.current:l:l;R?.focus()}),N=c.useMemo(()=>({close:T,isPortalled:h}),[T,h]),$=c.useMemo(()=>({open:s===0,close:T}),[s,T]),G=e,I={ref:a};return S.createElement(_t.Provider,{value:null},S.createElement(qn.Provider,{value:i},S.createElement(Vn.Provider,{value:N},S.createElement(Hn,{value:D(s,{0:_.Open,1:_.Closed})},Y({ourProps:I,theirProps:G,slot:$,defaultTag:kl,name:"Popover"})))))}let Sl="button";function Pl(e,t){let n=J(),{id:r=`headlessui-popover-button-${n}`,...a}=e,[o,i]=Dt("Popover.Button"),{isPortalled:s}=Xn("Popover.Button"),l=c.useRef(null),f=`headlessui-focus-sentinel-${J()}`,u=Ea(),d=u?.closeOthers,m=wl()!==null;c.useEffect(()=>{if(!m)return i({type:3,buttonId:r}),()=>{i({type:3,buttonId:null})}},[m,r,i]);let[b]=c.useState(()=>Symbol()),p=U(l,t,m?null:I=>{if(I)o.buttons.current.push(b);else{let P=o.buttons.current.indexOf(b);P!==-1&&o.buttons.current.splice(P,1)}o.buttons.current.length>1&&console.warn("You are already using a <Popover.Button /> but only 1 <Popover.Button /> is supported."),I&&i({type:2,button:I})}),v=U(l,t),h=Se(l),x=A(I=>{var P,R,Q;if(m){if(o.popoverState===1)return;switch(I.key){case F.Space:case F.Enter:I.preventDefault(),(R=(P=I.target).click)==null||R.call(P),i({type:1}),(Q=o.button)==null||Q.focus();break}}else switch(I.key){case F.Space:case F.Enter:I.preventDefault(),I.stopPropagation(),o.popoverState===1&&d?.(o.buttonId),i({type:0});break;case F.Escape:if(o.popoverState!==0)return d?.(o.buttonId);if(!l.current||h!=null&&h.activeElement&&!l.current.contains(h.activeElement))return;I.preventDefault(),I.stopPropagation(),i({type:1});break}}),g=A(I=>{m||I.key===F.Space&&I.preventDefault()}),O=A(I=>{var P,R;Ft(I.currentTarget)||e.disabled||(m?(i({type:1}),(P=o.button)==null||P.focus()):(I.preventDefault(),I.stopPropagation(),o.popoverState===1&&d?.(o.buttonId),i({type:0}),(R=o.button)==null||R.focus()))}),k=A(I=>{I.preventDefault(),I.stopPropagation()}),E=o.popoverState===0,j=c.useMemo(()=>({open:E}),[E]),T=ca(e,l),N=m?{ref:v,type:T,onKeyDown:x,onClick:O}:{ref:p,id:o.buttonId,type:T,"aria-expanded":e.disabled?void 0:o.popoverState===0,"aria-controls":o.panel?o.panelId:void 0,onKeyDown:x,onKeyUp:g,onClick:O,onMouseDown:k},$=Yn(),G=A(()=>{let I=o.panel;if(!I)return;function P(){D($.current,{[Z.Forwards]:()=>ne(I,X.First),[Z.Backwards]:()=>ne(I,X.Last)})===Je.Error&&ne(it().filter(R=>R.dataset.headlessuiFocusGuard!=="true"),D($.current,{[Z.Forwards]:X.Next,[Z.Backwards]:X.Previous}),{relativeTo:o.button})}P()});return S.createElement(S.Fragment,null,Y({ourProps:N,theirProps:a,slot:j,defaultTag:Sl,name:"Popover.Button"}),E&&!m&&s&&S.createElement(_e,{id:f,features:$e.Focusable,"data-headlessui-focus-guard":!0,as:"button",type:"button",onFocus:G}))}let Al="div",Ol=de.RenderStrategy|de.Static;function Tl(e,t){let n=J(),{id:r=`headlessui-popover-overlay-${n}`,...a}=e,[{popoverState:o},i]=Dt("Popover.Overlay"),s=U(t),l=He(),f=l!==null?(l&_.Open)===_.Open:o===0,u=A(m=>{if(Ft(m.currentTarget))return m.preventDefault();i({type:1})}),d=c.useMemo(()=>({open:o===0}),[o]);return Y({ourProps:{ref:s,id:r,"aria-hidden":!0,onClick:u},theirProps:a,slot:d,defaultTag:Al,features:Ol,visible:f,name:"Popover.Overlay"})}let Il="div",Cl=de.RenderStrategy|de.Static;function $l(e,t){let n=J(),{id:r=`headlessui-popover-panel-${n}`,focus:a=!1,...o}=e,[i,s]=Dt("Popover.Panel"),{close:l,isPortalled:f}=Xn("Popover.Panel"),u=`headlessui-focus-sentinel-before-${J()}`,d=`headlessui-focus-sentinel-after-${J()}`,m=c.useRef(null),b=U(m,t,T=>{s({type:4,panel:T})}),p=Se(m);V(()=>(s({type:5,panelId:r}),()=>{s({type:5,panelId:null})}),[r,s]);let v=He(),h=v!==null?(v&_.Open)===_.Open:i.popoverState===0,x=A(T=>{var N;switch(T.key){case F.Escape:if(i.popoverState!==0||!m.current||p!=null&&p.activeElement&&!m.current.contains(p.activeElement))return;T.preventDefault(),T.stopPropagation(),s({type:1}),(N=i.button)==null||N.focus();break}});c.useEffect(()=>{var T;e.static||i.popoverState===1&&((T=e.unmount)==null||T)&&s({type:4,panel:null})},[i.popoverState,e.unmount,e.static,s]),c.useEffect(()=>{if(!a||i.popoverState!==0||!m.current)return;let T=p?.activeElement;m.current.contains(T)||ne(m.current,X.First)},[a,m,i.popoverState]);let g=c.useMemo(()=>({open:i.popoverState===0,close:l}),[i,l]),O={ref:b,id:r,onKeyDown:x,onBlur:a&&i.popoverState===0?T=>{var N,$,G,I,P;let R=T.relatedTarget;R&&m.current&&((N=m.current)!=null&&N.contains(R)||(s({type:1}),((G=($=i.beforePanelSentinel.current)==null?void 0:$.contains)!=null&&G.call($,R)||(P=(I=i.afterPanelSentinel.current)==null?void 0:I.contains)!=null&&P.call(I,R))&&R.focus({preventScroll:!0})))}:void 0,tabIndex:-1},k=Yn(),E=A(()=>{let T=m.current;if(!T)return;function N(){D(k.current,{[Z.Forwards]:()=>{var $;ne(T,X.First)===Je.Error&&(($=i.afterPanelSentinel.current)==null||$.focus())},[Z.Backwards]:()=>{var $;($=i.button)==null||$.focus({preventScroll:!0})}})}N()}),j=A(()=>{let T=m.current;if(!T)return;function N(){D(k.current,{[Z.Forwards]:()=>{var $;if(!i.button)return;let G=it(),I=G.indexOf(i.button),P=G.slice(0,I+1),R=[...G.slice(I+1),...P];for(let Q of R.slice())if(Q.dataset.headlessuiFocusGuard==="true"||($=i.panel)!=null&&$.contains(Q)){let K=R.indexOf(Q);K!==-1&&R.splice(K,1)}ne(R,X.First,{sorted:!1})},[Z.Backwards]:()=>{var $;ne(T,X.Previous)===Je.Error&&(($=i.button)==null||$.focus())}})}N()});return S.createElement(_t.Provider,{value:r},h&&f&&S.createElement(_e,{id:u,ref:i.beforePanelSentinel,features:$e.Focusable,"data-headlessui-focus-guard":!0,as:"button",type:"button",onFocus:E}),Y({ourProps:O,theirProps:o,slot:g,defaultTag:Il,features:Cl,visible:h,name:"Popover.Panel"}),h&&f&&S.createElement(_e,{id:d,ref:i.afterPanelSentinel,features:$e.Focusable,"data-headlessui-focus-guard":!0,as:"button",type:"button",onFocus:j}))}let Rl="div";function Nl(e,t){let n=c.useRef(null),r=U(n,t),[a,o]=c.useState([]),i=A(p=>{o(v=>{let h=v.indexOf(p);if(h!==-1){let x=v.slice();return x.splice(h,1),x}return v})}),s=A(p=>(o(v=>[...v,p]),()=>i(p))),l=A(()=>{var p;let v=at(n);if(!v)return!1;let h=v.activeElement;return(p=n.current)!=null&&p.contains(h)?!0:a.some(x=>{var g,O;return((g=v.getElementById(x.buttonId.current))==null?void 0:g.contains(h))||((O=v.getElementById(x.panelId.current))==null?void 0:O.contains(h))})}),f=A(p=>{for(let v of a)v.buttonId.current!==p&&v.close()}),u=c.useMemo(()=>({registerPopover:s,unregisterPopover:i,isFocusWithinPopoverGroup:l,closeOthers:f}),[s,i,l,f]),d=c.useMemo(()=>({}),[]),m=e,b={ref:r};return S.createElement(Kn.Provider,{value:u},Y({ourProps:b,theirProps:m,slot:d,defaultTag:Rl,name:"Popover.Group"}))}let Fl=H(El),Ll=H(Pl),Ml=H(Tl),Dl=H($l),_l=H(Nl),su=Object.assign(Fl,{Button:Ll,Overlay:Ml,Panel:Dl,Group:_l});function jl(e=0){let[t,n]=c.useState(e),r=c.useCallback(s=>n(l=>l|s),[t]),a=c.useCallback(s=>!!(t&s),[t]),o=c.useCallback(s=>n(l=>l&~s),[n]),i=c.useCallback(s=>n(l=>l^s),[n]);return{flags:t,addFlag:r,hasFlag:a,removeFlag:o,toggleFlag:i}}function zl(e){let t={called:!1};return(...n)=>{if(!t.called)return t.called=!0,e(...n)}}function rn(e,...t){e&&t.length>0&&e.classList.add(...t)}function an(e,...t){e&&t.length>0&&e.classList.remove(...t)}function Hl(e,t){let n=ce();if(!e)return n.dispose;let{transitionDuration:r,transitionDelay:a}=getComputedStyle(e),[o,i]=[r,a].map(l=>{let[f=0]=l.split(",").filter(Boolean).map(u=>u.includes("ms")?parseFloat(u):parseFloat(u)*1e3).sort((u,d)=>d-u);return f}),s=o+i;if(s!==0){n.group(f=>{f.setTimeout(()=>{t(),f.dispose()},s),f.addEventListener(e,"transitionrun",u=>{u.target===u.currentTarget&&f.dispose()})});let l=n.addEventListener(e,"transitionend",f=>{f.target===f.currentTarget&&(t(),l())})}else t();return n.add(()=>t()),n.dispose}function Ul(e,t,n,r){let a=n?"enter":"leave",o=ce(),i=r!==void 0?zl(r):()=>{};a==="enter"&&(e.removeAttribute("hidden"),e.style.display="");let s=D(a,{enter:()=>t.enter,leave:()=>t.leave}),l=D(a,{enter:()=>t.enterTo,leave:()=>t.leaveTo}),f=D(a,{enter:()=>t.enterFrom,leave:()=>t.leaveFrom});return an(e,...t.enter,...t.enterTo,...t.enterFrom,...t.leave,...t.leaveFrom,...t.leaveTo,...t.entered),rn(e,...s,...f),o.nextFrame(()=>{an(e,...f),rn(e,...l),Hl(e,()=>(an(e,...s),rn(e,...t.entered),i()))}),o.dispose}function Yl({container:e,direction:t,classes:n,onStart:r,onStop:a}){let o=Lt(),i=rt(),s=oe(t);V(()=>{let l=ce();i.add(l.dispose);let f=e.current;if(f&&s.current!=="idle"&&o.current)return l.dispose(),r.current(s.current),l.add(Ul(f,n.current,s.current==="enter",()=>{l.dispose(),a.current(s.current)})),l.dispose},[t])}function Pe(e=""){return e.split(" ").filter(t=>t.trim().length>1)}let jt=c.createContext(null);jt.displayName="TransitionContext";var Wl=(e=>(e.Visible="visible",e.Hidden="hidden",e))(Wl||{});function Bl(){let e=c.useContext(jt);if(e===null)throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");return e}function Gl(){let e=c.useContext(zt);if(e===null)throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");return e}let zt=c.createContext(null);zt.displayName="NestingContext";function Ht(e){return"children"in e?Ht(e.children):e.current.filter(({el:t})=>t.current!==null).filter(({state:t})=>t==="visible").length>0}function Sa(e,t){let n=oe(e),r=c.useRef([]),a=Lt(),o=rt(),i=A((b,p=me.Hidden)=>{let v=r.current.findIndex(({el:h})=>h===b);v!==-1&&(D(p,{[me.Unmount](){r.current.splice(v,1)},[me.Hidden](){r.current[v].state="hidden"}}),o.microTask(()=>{var h;!Ht(r)&&a.current&&((h=n.current)==null||h.call(n))}))}),s=A(b=>{let p=r.current.find(({el:v})=>v===b);return p?p.state!=="visible"&&(p.state="visible"):r.current.push({el:b,state:"visible"}),()=>i(b,me.Unmount)}),l=c.useRef([]),f=c.useRef(Promise.resolve()),u=c.useRef({enter:[],leave:[],idle:[]}),d=A((b,p,v)=>{l.current.splice(0),t&&(t.chains.current[p]=t.chains.current[p].filter(([h])=>h!==b)),t?.chains.current[p].push([b,new Promise(h=>{l.current.push(h)})]),t?.chains.current[p].push([b,new Promise(h=>{Promise.all(u.current[p].map(([x,g])=>g)).then(()=>h())})]),p==="enter"?f.current=f.current.then(()=>t?.wait.current).then(()=>v(p)):v(p)}),m=A((b,p,v)=>{Promise.all(u.current[p].splice(0).map(([h,x])=>x)).then(()=>{var h;(h=l.current.shift())==null||h()}).then(()=>v(p))});return c.useMemo(()=>({children:r,register:s,unregister:i,onStart:d,onStop:m,wait:f,chains:u}),[s,i,r,d,m,u,f])}function ql(){}let Vl=["beforeEnter","afterEnter","beforeLeave","afterLeave"];function Rr(e){var t;let n={};for(let r of Vl)n[r]=(t=e[r])!=null?t:ql;return n}function Xl(e){let t=c.useRef(Rr(e));return c.useEffect(()=>{t.current=Rr(e)},[e]),t}let Kl="div",Pa=de.RenderStrategy;function Ql(e,t){let{beforeEnter:n,afterEnter:r,beforeLeave:a,afterLeave:o,enter:i,enterFrom:s,enterTo:l,entered:f,leave:u,leaveFrom:d,leaveTo:m,...b}=e,p=c.useRef(null),v=U(p,t),h=b.unmount?me.Unmount:me.Hidden,{show:x,appear:g,initial:O}=Bl(),[k,E]=c.useState(x?"visible":"hidden"),j=Gl(),{register:T,unregister:N}=j,$=c.useRef(null);c.useEffect(()=>T(p),[T,p]),c.useEffect(()=>{if(h===me.Hidden&&p.current){if(x&&k!=="visible"){E("visible");return}return D(k,{hidden:()=>N(p),visible:()=>T(p)})}},[k,p,T,N,x,h]);let G=oe({enter:Pe(i),enterFrom:Pe(s),enterTo:Pe(l),entered:Pe(f),leave:Pe(u),leaveFrom:Pe(d),leaveTo:Pe(m)}),I=Xl({beforeEnter:n,afterEnter:r,beforeLeave:a,afterLeave:o}),P=ze();c.useEffect(()=>{if(P&&k==="visible"&&p.current===null)throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?")},[p,k,P]);let R=O&&!g,Q=!P||R||$.current===x?"idle":x?"enter":"leave",K=jl(0),se=A(le=>D(le,{enter:()=>{K.addFlag(_.Opening),I.current.beforeEnter()},leave:()=>{K.addFlag(_.Closing),I.current.beforeLeave()},idle:()=>{}})),st=A(le=>D(le,{enter:()=>{K.removeFlag(_.Opening),I.current.afterEnter()},leave:()=>{K.removeFlag(_.Closing),I.current.afterLeave()},idle:()=>{}})),re=Sa(()=>{E("hidden"),N(p)},j);Yl({container:p,classes:G,direction:Q,onStart:oe(le=>{re.onStart(p,le,se)}),onStop:oe(le=>{re.onStop(p,le,st),le==="leave"&&!Ht(re)&&(E("hidden"),N(p))})}),c.useEffect(()=>{R&&(h===me.Hidden?$.current=null:$.current=x)},[x,R,k]);let lt=b,Ut={ref:v};return g&&x&&fe.isServer&&(lt={...lt,className:pa(b.className,...G.current.enter,...G.current.enterFrom)}),S.createElement(zt.Provider,{value:re},S.createElement(Hn,{value:D(k,{visible:_.Open,hidden:_.Closed})|K.flags},Y({ourProps:Ut,theirProps:lt,defaultTag:Kl,features:Pa,visible:k==="visible",name:"Transition.Child"})))}function Jl(e,t){let{show:n,appear:r=!1,unmount:a,...o}=e,i=c.useRef(null),s=U(i,t);ze();let l=He();if(n===void 0&&l!==null&&(n=(l&_.Open)===_.Open),![!0,!1].includes(n))throw new Error("A <Transition /> is used but it is missing a `show={true | false}` prop.");let[f,u]=c.useState(n?"visible":"hidden"),d=Sa(()=>{u("hidden")}),[m,b]=c.useState(!0),p=c.useRef([n]);V(()=>{m!==!1&&p.current[p.current.length-1]!==n&&(p.current.push(n),b(!1))},[p,n]);let v=c.useMemo(()=>({show:n,appear:r,initial:m}),[n,r,m]);c.useEffect(()=>{if(n)u("visible");else if(!Ht(d))u("hidden");else{let x=i.current;if(!x)return;let g=x.getBoundingClientRect();g.x===0&&g.y===0&&g.width===0&&g.height===0&&u("hidden")}},[n,d]);let h={unmount:a};return S.createElement(zt.Provider,{value:d},S.createElement(jt.Provider,{value:v},Y({ourProps:{...h,as:c.Fragment,children:S.createElement(Aa,{ref:s,...h,...o})},theirProps:{},defaultTag:c.Fragment,features:Pa,visible:f==="visible",name:"Transition"})))}function Zl(e,t){let n=c.useContext(jt)!==null,r=He()!==null;return S.createElement(S.Fragment,null,!n&&r?S.createElement(Pn,{ref:t,...e}):S.createElement(Aa,{ref:t,...e}))}let Pn=H(Jl),Aa=H(Ql),eu=H(Zl),lu=Object.assign(Pn,{Child:eu,Root:Pn});export{$t as F,su as L,iu as S,ou as o,lu as t};
